# Pulse Client

A client-side Fabric mod for real Minecraft: Java Edition **26.2**.

> **Warning:** ESP, X-ray, fly, speed, freecam, kill aura, reach, auto totem, criticals,
> anti-knockback, auto sprint, trigger bot and auto eat are cheats/QoL automation that most
> multiplayer servers prohibit; anti-cheat will kick or ban you for the combat ones especially.
> Use them in singleplayer, on a server you run (fly needs `allow-flight=true`), or on servers
> that explicitly allow them. Every module starts **off** every launch.

## Minecraft version

Pulse currently targets **Minecraft 26.2**. It does **not** load on 26.3 yet: 26.3 changed the
rendering system (new `renderpearl` packages, shaders and bind groups) and renamed some input
and player calls (for example `InputConstants.Type.KEYSYM` became `KEYBOARD`, and
`Player.swing` takes extra arguments), so the ESP/X-Ray drawing code needs a rewrite for it.

## Using with Meteor Client

Meteor Client 26.2 (build #35) also targets 26.2, so both mods can sit in the same `mods`
folder. Meteor's menu key is **Right Shift**; Pulse's default is now **Insert**, so they don't
clash. Meteor does not load alongside Feather. Download Meteor only from meteorclient.com.

## Keys (all rebindable in Options > Controls > Pulse Client)

| Key | Action |
|---|---|
| `Insert` | Open the Pulse menu (ESP / X-Ray / Movement settings) |
| `K` | Toggle ESP (master) |
| `X` | Toggle X-Ray (ores) |
| `V` | Toggle Fly |
| `B` | Toggle Speed |
| `N` | Toggle Freecam |
| `R` | Toggle Kill Aura |
| `J` | Toggle Reach |
| `;` | Toggle Auto Totem |
| `'` | Toggle Criticals |
| `[` | Toggle Anti-Knockback |
| `]` | Toggle Auto Sprint |
| `.` | Toggle Trigger Bot |
| `/` | Toggle Auto Respawn |
| `,` | Toggle Anti-AFK |
| `O` | Toggle Fullbright |
| `P` | Toggle Auto Eat |
| `C` (hold) | Zoom |
| `H` / `G` | Toggle info HUD / coordinates |

Active modules show on the HUD (ESP: ON, X-Ray: ON, Fly: ON, Speed: xN, Freecam: ON, KillAura: ON,
Reach: N, AutoTotem: ON, Criticals: ON, AntiKB: ON, AutoSprint: ON, TriggerBot: ON, AutoRespawn: ON,
AntiAFK: ON, Fullbright: ON, AutoEat: ON).

**Everything has a button.** The Insert menu has nine screens: HUD & Zoom (info HUD master,
FPS, coordinates, facing, zoom), ESP (master + each category), X-Ray (master + each ore),
Movement & Camera (fly, speed, freecam, plus speed presets), Combat (kill aura + reach),
Combat Extras (auto totem, criticals, anti-knockback, auto sprint, trigger bot), Utility
(auto respawn, anti-AFK, fullbright, auto eat), World Seed, and Updates (below). Every new
feature gets a toggle in this menu.

## Features

### Info HUD and zoom
FPS, XYZ, facing direction (top-left). Hold `C` to zoom.

### ESP (through-walls boxes)
Every category has its own ON/OFF button in the menu (Insert > ESP Settings):

| Category | Color | Config key |
|---|---|---|
| Players | white | `espPlayers` |
| Hostile mobs | red | `espHostile` |
| Passive mobs | green | `espPassive` (off by default) |
| Dropped items | yellow | `espItems` |
| Chests | orange | `espChests` |
| Trapped chests | red | `espTrappedChests` |
| Ender chests | purple | `espEnderChests` |
| Barrels | brown | `espBarrels` |
| Shulker boxes | pink | `espShulkers` |
| Spawners | cyan | `espSpawners` |
| Hoppers, furnaces, dispensers/droppers, brewing stands | grey | `espOtherStorage` (off by default) |

### X-Ray (ore highlighter)
Highlights ores through walls, with an ON/OFF button per ore (Insert > X-Ray Settings):
coal, iron, copper, gold (incl. nether gold), redstone, lapis, diamond, emerald, quartz,
ancient debris. Defaults on: iron, gold, diamond, emerald, ancient debris.

This is an *ore highlighter*, not see-through terrain. It reads the block data your client
has already received, so servers with anti-xray (which send fake ore) will show you wrong
results. `xrayRadius` (8-32, default 16) sets the scan size.

### Movement
- **Fly**: creative-style flight. Move with WASD, `Space` up, `Shift` down.
  Fly speed cycles through 0.25 / 0.5 / 1 / 2 blocks per tick in the Movement menu.
- **Speed**: multiplies walking speed (x1.5 / x2 / x3 / x5, cycle in the Movement menu).

### Kill Aura
Auto-attacks the nearest valid target in reach each time your attack cooldown is full, like
clicking by hand (no rotation changes). Starts **off**. Menu: Combat (Kill Aura) has the master
switch, a range button (3-6 blocks) and ON/OFF buttons for targeting players (off by default),
hostile mobs (on) and passive mobs (off). It has no anti-cheat evasion; servers will catch it.

### Reach
Raises your client-side hit and block-break distance (presets: hit 3.5-6, break 5-7 blocks;
Combat menu has the ON/OFF and amount buttons). Starts **off**. **Important:** it only changes
what your client attempts. The server checks every hit and block break against its own range
(vanilla: ~3 blocks plus a small buffer), so values much above 4 are ignored or flagged,
even in singleplayer. This also limits Kill Aura reach: 5-6 mostly won't land on vanilla servers.

### Auto Totem
Watches your health + absorption and, when it drops to or below a configurable threshold
(2-20, default 10, cycle in Combat Extras), moves a totem of undying from your hotbar/inventory
into your offhand automatically - if you're carrying one. Starts **off**. This is done with two
ordinary inventory clicks (the same thing you'd do by hand), not a packet trick, so it needs
no mixins and has no special anti-cheat evasion.

### Criticals
A critical hit in vanilla only happens while you're airborne and falling. When on, this makes
Kill Aura jump before it attacks and waits until you're falling again before the hit goes out -
real jump-timing, not a packet spoof. Starts **off**. Toggle in Combat Extras. Note: it currently
only affects Kill Aura's attacks, not manual clicks or Trigger Bot.

### Anti-Knockback
Softens the "pop" you get the instant you're hit, by scaling down your velocity on the tick
your hurt animation starts. Strength cycles 25% / 50% / 75% / 100% in Combat Extras. Starts
**off**. **This is an approximation, not a true cancel** - a full cancel means editing the
server's knockback packet before it's applied, which needs a mixin into the network code that
Pulse doesn't have yet. It only reduces the hit you just took; it shouldn't affect normal
jumping or sprinting.

### Auto Sprint
Keeps you sprinting while moving forward, so you don't have to hold the sprint key. Starts
**off**. It uses the same packet vanilla itself sends when you sprint by hand
(`ServerboundPlayerCommandPacket`), so it isn't flagged as cheating the way packet spoofing is -
it's genuinely just automating a keypress.

### Trigger Bot
Attacks whatever is directly under your crosshair the instant your attack cooldown is full and
the target is valid, instead of waiting for you to click. Starts **off**. Unlike Kill Aura it
never changes where you're looking - it only ever fires at what you're already aiming at.
Target types (players off, hostile mobs on, passive mobs off by default) are set in Combat
Extras, same as Kill Aura's.

### What's *not* included (and why)
True **packet-level No Fall Damage** and a precise **packet-level Anti-Knockback** (the kind
that edits the server's movement/motion packets before they're applied) both need Pulse's
first mixin - a new piece of build infrastructure (a `*.mixins.json`, a `"mixins"` entry in
`fabric.mod.json`, and an accessor mixin into Minecraft's network code) that doesn't exist in
this project yet. That's a bigger, riskier change than anything built so far, so it's left out
of this batch; the Anti-Knockback above is a tick-based approximation instead. Say the word if
you want mixin support added as its own step.

### Auto Respawn
Clicks "Respawn" for you the instant the death screen opens. Starts **off**. It's literally
the same call the Respawn button makes (`mc.player.respawn()`), just automatic.

### Anti-AFK
Occasionally jumps and slowly turns the camera so a server's AFK-kick timer doesn't trip while
you're away. Starts **off**. It can't stop you from dying to mobs, fall damage, or lava while
you're away, and won't fool a server checking for truly idle input devices rather than
in-game movement.

### Fullbright
Keeps the vanilla Night Vision effect topped up on you, lighting up dark areas - the same
effect a potion or beacon gives. Starts **off**. This is the mixin-free way to do fullbright;
a true gamma-override fullbright (like Meteor's) hooks directly into the lighting renderer and
needs a mixin Pulse doesn't have yet. Known quirk: turning this off while a *real* Night
Vision potion is also active will clear the potion's remaining time too (the game can't tell
the two apart).

### Auto Eat
Switches to food in your hotbar and holds right-click to eat it whenever your hunger drops to
a threshold (1-19, default 16, cycle in the Utility menu), then switches back to what you had
selected. Starts **off**. Only checks the hotbar, not your full inventory. The hotbar switch
sends the same packet vanilla sends when you scroll by hand, so the server always agrees about
what you're holding.

### World seed (not a cracker)
The menu's **World Seed** button shows and copies the real seed in **singleplayer**, where the
game already has it. On multiplayer servers the client is never sent the seed, so this can't
reveal it; use a real seed cracker such as the SeedcrackerX mod alongside Pulse for that.

### Updates (checks a GitHub repo you control, not any server of mine)
The **Updates** screen (Insert > Updates) checks a GitHub repo's Releases for a newer build
and lets you download it into your `mods` folder. It is **off by default in the sense that it
does nothing until you set a repo** - the `updateRepo` setting starts empty, so nothing is
ever contacted until you type an `owner/repo` in and save it.

How it actually works, so there's no mystery:
- **Checking** (on startup if "Check on startup" is ON, or via the "Check for updates"
  button) sends one GET to `https://api.github.com/repos/<owner>/<repo>/releases/latest` and
  compares its `tag_name` (e.g. `v1.1.0`) against the version baked into the jar you're running.
  This is read-only and happens on a background thread so it can't freeze the game.
- **Downloading** only happens when you click "Download update". It saves the release's `.jar`
  asset as `mods/pulseclient-<version>.jar`, next to your current jar. It does **not** delete
  the old jar and does **not** restart Minecraft - you do both of those yourself, same as
  installing any other mod update by hand. Nothing downloaded is ever run automatically.

To actually use this, push this project to your own GitHub repo (the included
`.github/workflows/build.yml` already builds it on every push), then push a version tag like
`git tag v1.1.0 && git push origin v1.1.0`. That triggers a `release` job that builds the jar
and publishes it as a GitHub Release with the jar attached - that's what the Updater reads.
**Before tagging, bump `mod_version` in `gradle.properties` to match the tag** (e.g. both
`1.1.0`), since that's what gets baked into the jar and compared against the tag. Then in
Pulse's Updates screen, set the repo to `your-username/your-repo-name` and save.

### Freecam
Detaches the camera from your body. Fly it with WASD (in the direction you look),
`Space` up, `Shift` down; your real character stays frozen in place. Toggle off to snap
back. Camera speed cycles through 0.25 / 0.5 / 1 / 2 blocks per tick in the menu.
ESP boxes and the ESP/X-ray scan range are still centered on your real character, not
the camera.

Settings are stored in `config/pulseclient.properties`.

## Easiest way to build

- **Windows:** double-click `build-and-install.bat`. It builds the jar and copies it into
  `%APPDATA%\.minecraft\mods` (you still need Fabric Loader and Fabric API installed).
- **No Java needed:** upload this folder to a GitHub repo; the included workflow
  (`.github/workflows/build.yml`) builds the jar and offers it as a download under Actions.

## Install (to play with it)

1. Install Minecraft Java Edition 26.2 (requires a Java Edition license).
2. Install Fabric Loader 0.19.5+ for 26.2 from https://fabricmc.net/use/installer/
3. Download Fabric API `0.161.0+26.2` (Modrinth or CurseForge) into your `mods` folder.
4. Put `build/libs/pulseclient-1.0.0.jar` (built below) into the same `mods` folder.
5. Launch the "fabric-loader-26.2" profile.

## Build

Requires **JDK 25** (Minecraft 26.x needs it).

```
./gradlew build          # Windows: gradlew.bat build
```

The mod jar ends up in `build/libs/` (use the one **without** `-sources`).

*Emailed copy?* Email services (Gmail etc.) block `.jar` files, so the emailed zip leaves out
`gradle/wrapper/gradle-wrapper.jar`. Install Gradle once, then run
`gradle wrapper --gradle-version 9.5.1` in this folder; after that `./gradlew build` works.

To test in a dev client without installing anything: `./gradlew runClient`

## Project layout

- `PulseClient.java`: entrypoint, key bindings, HUD, zoom
- `PulseConfig.java`: config file
- `EspScanner.java`: finds what to draw (entities per frame; chests/ores a few times a second)
- `EspRenderer.java`: through-walls box rendering (custom render pipeline, no depth test)
- `Movement.java`: fly and speed
- `Freecam.java`: detached camera
- `KillAura.java`, `Reach.java`, `CombatScreen.java`: kill aura, reach and their menu
- `AutoTotem.java`, `Criticals.java`, `AntiKnockback.java`, `AutoSprint.java`, `TriggerBot.java`,
  `CombatExtrasScreen.java`: the newer combat modules and their menu
- `AutoRespawn.java`, `AntiAFK.java`, `Fullbright.java`, `AutoEat.java`, `UtilityScreen.java`:
  the QoL/utility modules and their menu
- `SeedScreen.java`: singleplayer seed lookup / copy
- `Updater.java`, `UpdateScreen.java`: checks/downloads updates from a GitHub repo's Releases
- `PulseMenu.java`, `ToggleScreen.java`, `MovementScreen.java`: the menus
- `fabric.mod.json`, `assets/pulseclient/lang/en_us.json`: metadata and key names

## Notes

- At most 600 boxes are drawn at once (entities first, then chests/spawners, then ores);
  this keeps the GPU buffer from overflowing.
- The ESP draws filled boxes (no wireframes or tracer lines yet).
- Minecraft 26.x changed internals a lot. If a Mojang class or method is renamed in a
  future version, compiler errors will point at the exact line to fix.
