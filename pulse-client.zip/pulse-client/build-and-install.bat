@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo Pulse Client - build and install helper
echo Minecraft Java 26.2 / Fabric
echo ============================================
echo.

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found. Install a JDK 25 and reopen this window.
  echo Minecraft 26.x requires Java 25 for this project.
  pause
  exit /b 1
)

for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do set JAVA_VERSION=%%~V
 echo Detected Java: %JAVA_VERSION%
 echo.

java -version 2>&1 | findstr /c:"25." >nul
if errorlevel 1 (
  echo WARNING: This project targets Java 25. The detected Java may not be JDK 25.
  echo If the build fails with a Java version error, install JDK 25 and set JAVA_HOME.
  echo.
)

echo Building Pulse Client. Gradle may need internet access the first time.
call gradlew.bat build --no-daemon
if errorlevel 1 (
  echo.
  echo BUILD FAILED. No installable mod was created.
  echo Copy the full error above and send it back to Claude so the source can be fixed.
  pause
  exit /b 1
)

set "JAR=%~dp0build\libs\pulseclient-1.0.0.jar"
if not exist "%JAR%" (
  echo ERROR: Build reported success but expected JAR was not found:
  echo %JAR%
  pause
  exit /b 1
)

set "MODS=%APPDATA%\.minecraft\mods"
if not exist "%MODS%" mkdir "%MODS%"
copy /Y "%JAR%" "%MODS%\pulseclient-1.0.0.jar" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the JAR to %MODS%
  pause
  exit /b 1
)

echo.
echo SUCCESS: Pulse Client JAR copied to:
echo %MODS%\pulseclient-1.0.0.jar
echo Make sure Fabric Loader 26.2 and Fabric API for 26.2 are installed.
echo Launch the Fabric 26.2 profile in Minecraft Launcher.
pause
