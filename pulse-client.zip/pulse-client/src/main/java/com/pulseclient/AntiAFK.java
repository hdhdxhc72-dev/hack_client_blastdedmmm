package com.pulseclient;

import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * Occasionally jumps and slowly turns the camera so AFK-kick timers (which usually watch for
 * movement/rotation) don't trip while you're away. On/off state is runtime-only (starts off).
 * Won't stop a server that specifically checks for being "truly" idle (no input device state
 * changes), and won't keep you from dying to mobs/fall/lava while you're away.
 */
public final class AntiAFK {
	public static boolean enabled = false;

	private static final Random RANDOM = new Random();

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (!enabled || player == null || mc.screen != null) {
			return;
		}

		if (player.onGround() && RANDOM.nextInt(100) == 0) {
			player.jumpFromGround();
		}

		player.setYRot(player.getYRot() + 2.0f);
	}

	private AntiAFK() {
	}
}
