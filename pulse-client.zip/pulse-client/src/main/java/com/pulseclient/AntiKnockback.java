package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Softens the knockback "pop" you get the instant you're hit. On/off state is runtime-only
 * (starts off).
 *
 * This is an approximation, not a true cancel: a full cancel means editing the server's
 * knockback packet before it's applied, which needs a mixin into the network code, and Pulse
 * doesn't have one yet. Instead, the tick your hurt animation starts, this scales down your
 * current horizontal speed and any upward "pop" by the configured percentage. It does nothing
 * on other ticks, so it shouldn't make normal movement feel different.
 */
public final class AntiKnockback {
	public static boolean enabled = false;

	private static int lastHurtTime = 0;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null) {
			lastHurtTime = 0;
			return;
		}

		int hurtTime = player.hurtTime;
		boolean justHurt = enabled && hurtTime > 0 && lastHurtTime == 0;
		lastHurtTime = hurtTime;
		if (!justHurt) {
			return;
		}

		double keep = 1.0 - PulseConfig.antiKnockbackStrength(); // fraction of the knockback kept
		Vec3 v = player.getDeltaMovement();
		double newY = v.y > 0 ? v.y * keep : v.y; // only dampen the upward "pop", not normal falling
		player.setDeltaMovement(v.x * keep, newY, v.z * keep);
	}

	private AntiKnockback() {
	}
}
