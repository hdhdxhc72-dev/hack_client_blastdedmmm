package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.item.ItemStack;

/**
 * Switches to food in your hotbar and holds right-click to eat it whenever your hunger drops
 * to the configured threshold, then switches back to whatever you had selected. On/off state
 * is runtime-only (starts off). Only looks in the hotbar (not your full inventory) to keep
 * this simple.
 *
 * The hotbar switch sends the same packet (ServerboundSetCarriedItemPacket) vanilla sends when
 * you scroll your hotbar by hand, so the server always agrees about what you're holding.
 */
public final class AutoEat {
	public static boolean enabled = false;

	private static boolean eating = false;
	private static int prevSlot = -1;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null || mc.getConnection() == null) {
			return;
		}

		boolean hungry = enabled && player.getFoodData().getFoodLevel() <= PulseConfig.autoEatHunger;

		if (eating && (!hungry || !isFood(player.getInventory().getItem(player.getInventory().getSelectedSlot())))) {
			stopEating(mc, player);
		}

		if (!eating && hungry) {
			int slot = findFoodSlot(player);
			if (slot >= 0) {
				startEating(mc, player, slot);
			}
		}

		if (eating) {
			mc.options.keyUse.setDown(true);
		}
	}

	private static void startEating(Minecraft mc, LocalPlayer player, int slot) {
		prevSlot = player.getInventory().getSelectedSlot();
		player.getInventory().setSelectedSlot(slot);
		mc.getConnection().send(new ServerboundSetCarriedItemPacket(slot));
		eating = true;
	}

	private static void stopEating(Minecraft mc, LocalPlayer player) {
		mc.options.keyUse.setDown(false);
		if (prevSlot >= 0) {
			player.getInventory().setSelectedSlot(prevSlot);
			mc.getConnection().send(new ServerboundSetCarriedItemPacket(prevSlot));
		}
		eating = false;
		prevSlot = -1;
	}

	private static int findFoodSlot(LocalPlayer player) {
		for (int i = 0; i < 9; i++) {
			if (isFood(player.getInventory().getItem(i))) {
				return i;
			}
		}
		return -1;
	}

	private static boolean isFood(ItemStack stack) {
		return stack != null && !stack.isEmpty() && stack.get(DataComponents.FOOD) != null;
	}

	private AutoEat() {
	}
}
