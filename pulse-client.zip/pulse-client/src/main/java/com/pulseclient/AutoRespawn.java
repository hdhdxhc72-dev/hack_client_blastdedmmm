package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;

/**
 * Clicks "Respawn" for you the instant the death screen opens. On/off state is runtime-only
 * (starts off). This is just the same thing the Respawn button itself does
 * (`mc.player.respawn()`), fired automatically instead of waiting for a click.
 */
public final class AutoRespawn {
	public static boolean enabled = false;

	public static void tick(Minecraft mc) {
		if (!enabled || mc.player == null || !(mc.screen instanceof DeathScreen)) {
			return;
		}
		mc.player.respawn();
		mc.gui.setScreen(null);
	}

	private AutoRespawn() {
	}
}
