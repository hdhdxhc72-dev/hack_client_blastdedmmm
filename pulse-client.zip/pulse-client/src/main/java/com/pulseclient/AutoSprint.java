package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;

/**
 * Keeps you sprinting whenever you're moving forward, so you don't need to hold the sprint
 * key. On/off state is runtime-only (starts off). Stops itself while hungry, sneaking, using
 * an item, or not moving forward, same as vanilla's own sprint rules.
 */
public final class AutoSprint {
	public static boolean enabled = false;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (!enabled || player == null || mc.screen != null || mc.getConnection() == null) {
			return;
		}

		boolean forward = mc.options.keyUp.isDown() && !mc.options.keyDown.isDown();
		boolean canSprint = forward && !player.isCrouching() && !player.isUsingItem()
				&& player.getFoodData().getFoodLevel() > 6;

		if (canSprint && !player.isSprinting()) {
			player.setSprinting(true);
			mc.getConnection().send(new ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
		} else if (!canSprint && player.isSprinting() && !mc.options.keySprint.isDown()) {
			player.setSprinting(false);
			mc.getConnection().send(new ServerboundPlayerCommandPacket(player, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
		}
	}

	private AutoSprint() {
	}
}
