package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;

/**
 * Moves a totem of undying from your hotbar/inventory into your offhand when your effective
 * health (health + absorption) drops to the configured threshold. On/off state is runtime-only
 * (starts off).
 *
 * Implemented with two ordinary inventory clicks (pick up the totem, then place it in the
 * offhand slot) - the same thing you'd do by hand, not a packet trick, so it needs no mixins.
 */
public final class AutoTotem {
	public static boolean enabled = false;

	private static final int OFFHAND_SLOT_ID = 45; // default player inventory menu: see Inventory/InventoryMenu slot layout

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (!enabled || player == null || mc.gameMode == null || mc.level == null) {
			return;
		}
		if (player.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) {
			return;
		}

		double effectiveHealth = player.getHealth() + player.getAbsorptionAmount();
		if (effectiveHealth > PulseConfig.autoTotemHealth) {
			return;
		}

		int slotId = findTotemSlotId(player);
		if (slotId < 0) {
			return;
		}

		int containerId = player.containerMenu.containerId;
		mc.gameMode.handleContainerInput(containerId, slotId, 0, ContainerInput.PICKUP, player);
		mc.gameMode.handleContainerInput(containerId, OFFHAND_SLOT_ID, 0, ContainerInput.PICKUP, player);
	}

	/** Container-menu slot id (not inventory index) of a totem in the hotbar or main inventory, or -1. */
	private static int findTotemSlotId(LocalPlayer player) {
		for (int i = 0; i < 36; i++) {
			if (player.getInventory().getItem(i).getItem() == Items.TOTEM_OF_UNDYING) {
				return i < 9 ? 36 + i : i; // hotbar (0-8) -> ids 36-44; main (9-35) -> same id
			}
		}
		return -1;
	}

	private AutoTotem() {
	}
}
