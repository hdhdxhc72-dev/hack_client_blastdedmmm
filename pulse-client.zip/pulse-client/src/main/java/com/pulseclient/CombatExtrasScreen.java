package com.pulseclient;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Auto Totem, Criticals, Anti-Knockback, Auto Sprint and Trigger Bot settings. */
public class CombatExtrasScreen extends Screen {
	private final Screen parent;

	public CombatExtrasScreen(Screen parent) {
		super(Component.literal("Pulse Client - Combat Extras"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 240;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		int y = Math.max(30, this.height / 2 - 123);

		this.addRenderableWidget(Button.builder(totemLabel(), (btn) -> {
			AutoTotem.enabled = !AutoTotem.enabled;
			btn.setMessage(totemLabel());
		}).bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(totemHealthLabel(), (btn) -> {
			// Cycle 2 -> 4 -> ... -> 20 -> 2 (half-heart steps of 2 = 1 heart)
			PulseConfig.autoTotemHealth = PulseConfig.autoTotemHealth >= 20 ? 2 : PulseConfig.autoTotemHealth + 2;
			btn.setMessage(totemHealthLabel());
			PulseConfig.save();
		}).bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(criticalsLabel(), (btn) -> {
			Criticals.enabled = !Criticals.enabled;
			btn.setMessage(criticalsLabel());
		}).bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(antiKbLabel(), (btn) -> {
			AntiKnockback.enabled = !AntiKnockback.enabled;
			btn.setMessage(antiKbLabel());
		}).bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(antiKbStrengthLabel(), (btn) -> {
			PulseConfig.antiKnockbackIndex = (PulseConfig.antiKnockbackIndex + 1) % PulseConfig.ANTIKB_STRENGTHS.length;
			btn.setMessage(antiKbStrengthLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(autoSprintLabel(), (btn) -> {
			AutoSprint.enabled = !AutoSprint.enabled;
			btn.setMessage(autoSprintLabel());
		}).bounds(x, y + step * 5, w, h).build());

		this.addRenderableWidget(Button.builder(triggerBotLabel(), (btn) -> {
			TriggerBot.enabled = !TriggerBot.enabled;
			btn.setMessage(triggerBotLabel());
		}).bounds(x, y + step * 6, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Trigger: players", PulseConfig.triggerbotPlayers), (btn) -> {
			PulseConfig.triggerbotPlayers = !PulseConfig.triggerbotPlayers;
			btn.setMessage(targetLabel("Trigger: players", PulseConfig.triggerbotPlayers));
			PulseConfig.save();
		}).bounds(x, y + step * 7, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Trigger: hostile mobs", PulseConfig.triggerbotHostile), (btn) -> {
			PulseConfig.triggerbotHostile = !PulseConfig.triggerbotHostile;
			btn.setMessage(targetLabel("Trigger: hostile mobs", PulseConfig.triggerbotHostile));
			PulseConfig.save();
		}).bounds(x, y + step * 8, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Trigger: passive mobs", PulseConfig.triggerbotPassive), (btn) -> {
			PulseConfig.triggerbotPassive = !PulseConfig.triggerbotPassive;
			btn.setMessage(targetLabel("Trigger: passive mobs", PulseConfig.triggerbotPassive));
			PulseConfig.save();
		}).bounds(x, y + step * 9, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 10 + 6, 150, h)
				.build());
	}

	private static Component totemLabel() {
		return Component.literal("Auto Totem: " + (AutoTotem.enabled ? "ON" : "OFF"));
	}

	private static Component totemHealthLabel() {
		return Component.literal("Swap at health: " + (int) PulseConfig.autoTotemHealth + " (click to change)");
	}

	private static Component criticalsLabel() {
		return Component.literal("Criticals (jump-crit, boosts Kill Aura): " + (Criticals.enabled ? "ON" : "OFF"));
	}

	private static Component antiKbLabel() {
		return Component.literal("Anti-Knockback (approximate): " + (AntiKnockback.enabled ? "ON" : "OFF"));
	}

	private static Component antiKbStrengthLabel() {
		return Component.literal("Anti-KB strength: " + (int) (PulseConfig.antiKnockbackStrength() * 100) + "% (click)");
	}

	private static Component autoSprintLabel() {
		return Component.literal("Auto Sprint: " + (AutoSprint.enabled ? "ON" : "OFF"));
	}

	private static Component triggerBotLabel() {
		return Component.literal("Trigger Bot: " + (TriggerBot.enabled ? "ON" : "OFF"));
	}

	private static Component targetLabel(String name, boolean on) {
		return Component.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
