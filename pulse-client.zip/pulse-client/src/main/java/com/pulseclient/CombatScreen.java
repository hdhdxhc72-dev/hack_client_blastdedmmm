package com.pulseclient;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Kill Aura settings: master switch, reach, and which target types are attacked. */
public class CombatScreen extends Screen {
	private final Screen parent;

	public CombatScreen(Screen parent) {
		super(Component.literal("Pulse Client - Combat (Kill Aura & Reach)"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 220;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		int y = Math.max(30, this.height / 2 - 99);

		this.addRenderableWidget(Button.builder(auraLabel(), (btn) -> {
			KillAura.enabled = !KillAura.enabled;
			btn.setMessage(auraLabel());
		}).bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(rangeLabel(), (btn) -> {
			// Cycle 3 -> 4 -> 5 -> 6 -> 3
			PulseConfig.killauraRange = PulseConfig.killauraRange >= 6 ? 3 : PulseConfig.killauraRange + 1;
			btn.setMessage(rangeLabel());
			PulseConfig.save();
		}).bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Target players", PulseConfig.killauraPlayers), (btn) -> {
			PulseConfig.killauraPlayers = !PulseConfig.killauraPlayers;
			btn.setMessage(targetLabel("Target players", PulseConfig.killauraPlayers));
			PulseConfig.save();
		}).bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Target hostile mobs", PulseConfig.killauraHostile), (btn) -> {
			PulseConfig.killauraHostile = !PulseConfig.killauraHostile;
			btn.setMessage(targetLabel("Target hostile mobs", PulseConfig.killauraHostile));
			PulseConfig.save();
		}).bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(targetLabel("Target passive mobs", PulseConfig.killauraPassive), (btn) -> {
			PulseConfig.killauraPassive = !PulseConfig.killauraPassive;
			btn.setMessage(targetLabel("Target passive mobs", PulseConfig.killauraPassive));
			PulseConfig.save();
		}).bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(reachLabel(), (btn) -> {
			Reach.enabled = !Reach.enabled;
			btn.setMessage(reachLabel());
		}).bounds(x, y + step * 5, w, h).build());

		this.addRenderableWidget(Button.builder(reachAmountLabel(), (btn) -> {
			PulseConfig.reachIndex = (PulseConfig.reachIndex + 1) % PulseConfig.REACH_ENTITY.length;
			btn.setMessage(reachAmountLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 6, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 7 + 6, 150, h)
				.build());
	}

	private static Component auraLabel() {
		return Component.literal("Kill Aura: " + (KillAura.enabled ? "ON" : "OFF"));
	}

	private static Component rangeLabel() {
		return Component.literal("Kill Aura range: " + PulseConfig.killauraRange + " blocks (click to change)");
	}

	private static Component reachLabel() {
		return Component.literal("Reach: " + (Reach.enabled ? "ON" : "OFF"));
	}

	private static Component reachAmountLabel() {
		return Component.literal("Reach amount: hit " + PulseConfig.reachEntity() + " / break "
				+ PulseConfig.reachBlock() + " (click)");
	}

	private static Component targetLabel(String name, boolean on) {
		return Component.literal(name + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
