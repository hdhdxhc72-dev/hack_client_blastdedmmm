package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * Jump-crit helper used by {@link KillAura}: a vanilla attack only counts as a critical hit
 * while the attacker is airborne and falling. On/off state is runtime-only (starts off).
 *
 * This does not spoof any packets. When a target is in range and you're standing on the
 * ground, it makes you jump and waits until you're falling again before the hit goes out -
 * the same timing a player would use by hand, just automated.
 */
public final class Criticals {
	public static boolean enabled = false;

	private static boolean jumping = false;
	private static double lastY = 0;

	/**
	 * Call this right before KillAura would attack. Returns true if it's fine to attack this
	 * tick, or false if Criticals just started (or is still mid-) a jump and the attack should
	 * wait for a later tick.
	 */
	public static boolean readyToAttack(Minecraft mc) {
		if (!enabled) {
			return true;
		}
		LocalPlayer player = mc.player;
		if (player == null) {
			return true;
		}

		if (!jumping) {
			if (player.onGround()) {
				player.jumpFromGround();
				jumping = true;
				lastY = player.getY();
				return false;
			}
			return true; // already airborne for some other reason (fell off a block, etc.)
		}

		double y = player.getY();
		boolean pastPeak = y <= lastY;
		lastY = y;
		if (!pastPeak) {
			return false; // still rising
		}
		jumping = false;
		return true; // now falling: this hit will be a critical
	}

	private Criticals() {
	}
}
