package com.pulseclient;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.StagedVertexBuffer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

/**
 * Draws translucent filled boxes through walls.
 * Follows the Fabric docs "custom render pipeline" pattern: a pipeline with the depth
 * test removed, a staged vertex buffer, and one indexed draw per frame.
 */
public final class EspRenderer {
	private static final RenderPipeline FILLED_THROUGH_WALLS = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
					.withLocation(Identifier.fromNamespaceAndPath(PulseClient.MOD_ID, "pipeline/esp_filled_through_walls"))
					.withDepthStencilState(Optional.empty())
					.build());

	private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
	private static final Vector3f MODEL_OFFSET = new Vector3f();
	private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

	private static final StagedVertexBuffer stagedBuffer = new StagedVertexBuffer(
			() -> "Pulse ESP Buffer", RenderType.SMALL_BUFFER_SIZE);

	/** Boxes for the frame being rendered; replaced (never mutated) during extraction. */
	private static volatile List<EspScanner.Box> frameBoxes = List.of();

	public static void init() {
		LevelExtractionEvents.END_EXTRACTION.register(EspRenderer::extract);
		LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(EspRenderer::renderAndDraw);
	}

	/** Extraction phase: read the world, publish an immutable snapshot. */
	private static void extract(LevelExtractionContext context) {
		frameBoxes = EspScanner.collect(Minecraft.getInstance());
	}

	/** Drawing phase: only touches the immutable snapshot. */
	private static void renderAndDraw(LevelRenderContext context) {
		List<EspScanner.Box> boxes = frameBoxes;
		if (boxes.isEmpty()) {
			return;
		}

		RenderPipeline renderPipeline = FILLED_THROUGH_WALLS;
		VertexFormat formatBinding = renderPipeline.getVertexFormatBinding(0);
		assert formatBinding != null;
		PrimitiveTopology primitive = renderPipeline.getPrimitiveTopology();

		StagedVertexBuffer.Draw draw = stagedBuffer.appendDraw(formatBinding, primitive,
				primitive == PrimitiveTopology.QUADS ? RenderSystem.getProjectionType().vertexSorting() : null);

		writeBoxes(context, draw, boxes);

		stagedBuffer.upload();
		StagedVertexBuffer.ExecuteInfo info = stagedBuffer.getExecuteInfo(draw);
		if (info != null) {
			draw(Minecraft.getInstance(), info, renderPipeline);
		}
		stagedBuffer.endFrame();
	}

	private static void writeBoxes(LevelRenderContext context, StagedVertexBuffer.Draw draw, List<EspScanner.Box> boxes) {
		PoseStack matrices = context.poseStack();
		Vec3 camera = context.levelState().cameraRenderState.pos;

		matrices.pushPose();
		final var builder = stagedBuffer.getVertexBuilder(draw);
		Matrix4fc pose = matrices.last().pose();

		int count = Math.min(boxes.size(), EspScanner.MAX_BOXES);
		for (int i = 0; i < count; i++) {
			EspScanner.Box b = boxes.get(i);
			// Subtract the camera in double precision, then narrow to float:
			// avoids jitter far from the world origin.
			filledBox(pose, builder,
					(float) (b.minX() - camera.x), (float) (b.minY() - camera.y), (float) (b.minZ() - camera.z),
					(float) (b.maxX() - camera.x), (float) (b.maxY() - camera.y), (float) (b.maxZ() - camera.z),
					b.r(), b.g(), b.b(), b.a());
		}
		matrices.popPose();
	}

	private static void filledBox(Matrix4fc m, VertexConsumer buffer,
			float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
			float red, float green, float blue, float alpha) {
		// Front face
		buffer.addVertex(m, minX, minY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, minY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, maxY, maxZ).setColor(red, green, blue, alpha);
		// Back face
		buffer.addVertex(m, maxX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, maxY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, minZ).setColor(red, green, blue, alpha);
		// Left face
		buffer.addVertex(m, minX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, minY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, maxY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, maxY, minZ).setColor(red, green, blue, alpha);
		// Right face
		buffer.addVertex(m, maxX, minY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
		// Top face
		buffer.addVertex(m, minX, maxY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, maxY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, maxY, minZ).setColor(red, green, blue, alpha);
		// Bottom face
		buffer.addVertex(m, minX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, minY, minZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, maxX, minY, maxZ).setColor(red, green, blue, alpha);
		buffer.addVertex(m, minX, minY, maxZ).setColor(red, green, blue, alpha);
	}

	private static void draw(Minecraft client, StagedVertexBuffer.ExecuteInfo info, RenderPipeline pipeline) {
		GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
				.writeTransform(RenderSystem.getModelViewMatrixCopy(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

		RenderTarget mainTarget = client.gameRenderer.mainRenderTarget();
		GpuTextureView colorTexture = mainTarget.getColorTextureView();
		assert colorTexture != null;

		try (RenderPass renderPass = RenderSystem.getDevice()
				.createCommandEncoder()
				.createRenderPass(() -> PulseClient.MOD_ID + " esp rendering", colorTexture,
						Optional.empty(), mainTarget.getDepthTextureView(), OptionalDouble.empty())) {
			renderPass.setPipeline(pipeline);
			RenderSystem.bindDefaultUniforms(renderPass);
			renderPass.setUniform("DynamicTransforms", dynamicTransforms);

			renderPass.setVertexBuffer(0, info.vertexBuffer().slice());
			renderPass.setIndexBuffer(info.indexBuffer(), info.indexType());

			// The base vertex is the starting index when the data was copied into the vertex buffer.
			renderPass.drawIndexed(info.indexCount(), 1, info.firstIndex(), info.baseVertex(), 0);
		}
	}

	/** Release GPU resources. Called when the client is stopping. */
	public static void close() {
		stagedBuffer.close();
	}

	private EspRenderer() {
	}
}
