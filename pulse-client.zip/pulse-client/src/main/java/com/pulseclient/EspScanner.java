package com.pulseclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BrewingStandBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

/**
 * Collects the boxes the ESP / X-ray draws.
 * - Entities are gathered every frame (extraction phase) so they move smoothly.
 * - Block entities (chests, spawners...) and ores are scanned a few times per second.
 */
public final class EspScanner {
	/** Immutable, thread-safe description of one box to draw (world coordinates). */
	public record Box(double minX, double minY, double minZ,
			double maxX, double maxY, double maxZ,
			float r, float g, float b, float a) {
	}

	/** Hard cap so we never overflow the GPU staging buffer. */
	public static final int MAX_BOXES = 600;
	private static final int ENTITY_CAP = 200;
	private static final int BLOCK_CAP = 200;
	private static final int ORE_CAP = 300;

	// RGB colors per category (alpha comes from config).
	private static final float[] PLAYER = {1.00f, 1.00f, 1.00f};
	private static final float[] HOSTILE = {1.00f, 0.20f, 0.20f};
	private static final float[] PASSIVE = {0.30f, 1.00f, 0.30f};
	private static final float[] ITEM = {1.00f, 0.90f, 0.20f};
	private static final float[] CHEST = {1.00f, 0.60f, 0.10f};
	private static final float[] TRAPPED = {1.00f, 0.10f, 0.10f};
	private static final float[] ENDER = {0.65f, 0.25f, 1.00f};
	private static final float[] BARREL = {0.60f, 0.40f, 0.20f};
	private static final float[] SHULKER = {1.00f, 0.45f, 0.80f};
	private static final float[] SPAWNER = {0.10f, 0.90f, 1.00f};
	private static final float[] OTHER = {0.70f, 0.70f, 0.70f};

	/** An ore type: its highlight color and whether it's currently switched on. */
	private record Ore(float[] color, BooleanSupplier enabled) {
	}

	private static final Map<Block, Ore> ORES = new HashMap<>();

	static {
		Ore coal = new Ore(new float[] {0.25f, 0.25f, 0.25f}, () -> PulseConfig.xrayCoal);
		Ore iron = new Ore(new float[] {0.85f, 0.70f, 0.60f}, () -> PulseConfig.xrayIron);
		Ore copper = new Ore(new float[] {0.90f, 0.50f, 0.25f}, () -> PulseConfig.xrayCopper);
		Ore gold = new Ore(new float[] {1.00f, 0.85f, 0.10f}, () -> PulseConfig.xrayGold);
		Ore redstone = new Ore(new float[] {1.00f, 0.00f, 0.00f}, () -> PulseConfig.xrayRedstone);
		Ore lapis = new Ore(new float[] {0.15f, 0.30f, 1.00f}, () -> PulseConfig.xrayLapis);
		Ore diamond = new Ore(new float[] {0.20f, 1.00f, 1.00f}, () -> PulseConfig.xrayDiamond);
		Ore emerald = new Ore(new float[] {0.10f, 1.00f, 0.30f}, () -> PulseConfig.xrayEmerald);
		Ore quartz = new Ore(new float[] {0.95f, 0.95f, 0.90f}, () -> PulseConfig.xrayQuartz);
		Ore debris = new Ore(new float[] {0.55f, 0.25f, 0.15f}, () -> PulseConfig.xrayDebris);

		ORES.put(Blocks.COAL_ORE, coal);
		ORES.put(Blocks.DEEPSLATE_COAL_ORE, coal);
		ORES.put(Blocks.IRON_ORE, iron);
		ORES.put(Blocks.DEEPSLATE_IRON_ORE, iron);
		ORES.put(Blocks.COPPER_ORE, copper);
		ORES.put(Blocks.DEEPSLATE_COPPER_ORE, copper);
		ORES.put(Blocks.GOLD_ORE, gold);
		ORES.put(Blocks.DEEPSLATE_GOLD_ORE, gold);
		ORES.put(Blocks.NETHER_GOLD_ORE, gold);
		ORES.put(Blocks.REDSTONE_ORE, redstone);
		ORES.put(Blocks.DEEPSLATE_REDSTONE_ORE, redstone);
		ORES.put(Blocks.LAPIS_ORE, lapis);
		ORES.put(Blocks.DEEPSLATE_LAPIS_ORE, lapis);
		ORES.put(Blocks.DIAMOND_ORE, diamond);
		ORES.put(Blocks.DEEPSLATE_DIAMOND_ORE, diamond);
		ORES.put(Blocks.EMERALD_ORE, emerald);
		ORES.put(Blocks.DEEPSLATE_EMERALD_ORE, emerald);
		ORES.put(Blocks.NETHER_QUARTZ_ORE, quartz);
		ORES.put(Blocks.ANCIENT_DEBRIS, debris);
	}

	private static volatile List<Box> blockBoxes = List.of();
	private static volatile List<Box> oreBoxes = List.of();

	// ------------------------------------------------------------------ block entities

	/** Rescan nearby loaded chunks for block entities. Call from the client tick. */
	public static void scanBlocks(Minecraft mc) {
		if (!PulseConfig.espEnabled || mc.level == null || mc.player == null) {
			blockBoxes = List.of();
			return;
		}

		float alpha = PulseConfig.espAlphaPercent / 100f;
		List<Box> out = new ArrayList<>();
		BlockPos origin = mc.player.blockPosition();
		int centerX = origin.getX() >> 4;
		int centerZ = origin.getZ() >> 4;
		int radius = PulseConfig.espChunkRadius;

		scan:
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				LevelChunk chunk = mc.level.getChunk(centerX + dx, centerZ + dz);
				for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
					float[] color = colorFor(be);
					if (color == null) {
						continue;
					}
					BlockPos pos = be.getBlockPos();
					out.add(new Box(pos.getX(), pos.getY(), pos.getZ(),
							pos.getX() + 1.0, pos.getY() + 1.0, pos.getZ() + 1.0,
							color[0], color[1], color[2], alpha));
					if (out.size() >= BLOCK_CAP) {
						break scan;
					}
				}
			}
		}
		blockBoxes = List.copyOf(out);
	}

	/** Returns the RGB color if this block entity should be drawn, else null. */
	private static float[] colorFor(BlockEntity be) {
		// Trapped chest extends chest, so test it first.
		if (be instanceof TrappedChestBlockEntity) {
			return PulseConfig.espTrappedChests ? TRAPPED : null;
		}
		if (be instanceof ChestBlockEntity) {
			return PulseConfig.espChests ? CHEST : null;
		}
		if (be instanceof EnderChestBlockEntity) {
			return PulseConfig.espEnderChests ? ENDER : null;
		}
		if (be instanceof BarrelBlockEntity) {
			return PulseConfig.espBarrels ? BARREL : null;
		}
		if (be instanceof ShulkerBoxBlockEntity) {
			return PulseConfig.espShulkers ? SHULKER : null;
		}
		if (be instanceof SpawnerBlockEntity) {
			return PulseConfig.espSpawners ? SPAWNER : null;
		}
		if (be instanceof HopperBlockEntity
				|| be instanceof AbstractFurnaceBlockEntity
				|| be instanceof DispenserBlockEntity
				|| be instanceof BrewingStandBlockEntity) {
			return PulseConfig.espOtherStorage ? OTHER : null;
		}
		return null;
	}

	// ------------------------------------------------------------------ ores (X-ray)

	/**
	 * Scan the cube around the player for ores. Uses the block data the server has already
	 * sent to the client. Call from the client tick (about once per second).
	 */
	public static void scanOres(Minecraft mc) {
		if (!PulseConfig.xrayEnabled || mc.level == null || mc.player == null) {
			oreBoxes = List.of();
			return;
		}

		float alpha = Math.min(1f, PulseConfig.espAlphaPercent / 100f + 0.15f);
		List<Box> out = new ArrayList<>();
		BlockPos origin = mc.player.blockPosition();
		int r = PulseConfig.xrayRadius;
		BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

		scan:
		for (int x = origin.getX() - r; x <= origin.getX() + r; x++) {
			for (int z = origin.getZ() - r; z <= origin.getZ() + r; z++) {
				for (int y = origin.getY() - r; y <= origin.getY() + r; y++) {
					cursor.set(x, y, z);
					BlockState state = mc.level.getBlockState(cursor);
					if (state.isAir()) {
						continue;
					}
					Ore ore = ORES.get(state.getBlock());
					if (ore == null || !ore.enabled().getAsBoolean()) {
						continue;
					}
					float[] c = ore.color();
					out.add(new Box(x, y, z, x + 1.0, y + 1.0, z + 1.0, c[0], c[1], c[2], alpha));
					if (out.size() >= ORE_CAP) {
						break scan;
					}
				}
			}
		}
		oreBoxes = List.copyOf(out);
	}

	// ------------------------------------------------------------------ per-frame collection

	/**
	 * Builds the full list of boxes for this frame. Runs in the extraction phase,
	 * where reading the world is allowed; the result is immutable for the draw phase.
	 * Entities are added first so they are never the ones dropped when the budget is full.
	 */
	public static List<Box> collect(Minecraft mc) {
		if (mc.level == null || mc.player == null) {
			return List.of();
		}
		List<Box> out = new ArrayList<>();

		if (PulseConfig.espEnabled) {
			collectEntities(mc, out);
			for (Box b : blockBoxes) {
				if (out.size() >= MAX_BOXES) {
					break;
				}
				out.add(b);
			}
		}
		if (PulseConfig.xrayEnabled) {
			for (Box b : oreBoxes) {
				if (out.size() >= MAX_BOXES) {
					break;
				}
				out.add(b);
			}
		}
		return List.copyOf(out);
	}

	private static void collectEntities(Minecraft mc, List<Box> out) {
		boolean wantsEntities = PulseConfig.espPlayers || PulseConfig.espHostile
				|| PulseConfig.espPassive || PulseConfig.espItems;
		if (!wantsEntities) {
			return;
		}
		float alpha = PulseConfig.espAlphaPercent / 100f;
		double range = PulseConfig.espEntityRange;
		double rangeSq = range * range;
		AABB area = mc.player.getBoundingBox().inflate(range);
		int added = 0;

		for (Entity e : mc.level.getEntities(mc.player, area, entity -> true)) {
			if (added >= ENTITY_CAP) {
				break;
			}
			if (e.distanceToSqr(mc.player) > rangeSq) {
				continue;
			}
			float[] color = colorFor(e);
			if (color == null) {
				continue;
			}
			AABB bb = e.getBoundingBox();
			out.add(new Box(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ,
					color[0], color[1], color[2], alpha));
			added++;
		}
	}

	private static float[] colorFor(Entity e) {
		if (e instanceof Player) {
			return PulseConfig.espPlayers ? PLAYER : null;
		}
		if (e instanceof ItemEntity) {
			return PulseConfig.espItems ? ITEM : null;
		}
		if (e instanceof Enemy) {
			return PulseConfig.espHostile ? HOSTILE : null;
		}
		if (e instanceof Mob) {
			return PulseConfig.espPassive ? PASSIVE : null;
		}
		return null;
	}

	private EspScanner() {
	}
}
