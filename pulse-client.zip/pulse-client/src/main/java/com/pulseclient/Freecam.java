package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;

/**
 * Detached camera. A client-only invisible entity (never added to the world) becomes the
 * camera; the real player is held in place while you fly the camera around.
 * Camera movement and rotation are updated every frame, so it stays smooth.
 *
 * Servers can't see the camera, but they do see your real (frozen) position. Some servers
 * ban freecam; use it in singleplayer or where it's allowed.
 */
public final class Freecam {
	public static boolean enabled = false;

	private static Marker camera;
	private static double savedX;
	private static double savedY;
	private static double savedZ;
	private static long lastNanos;

	public static void toggle(Minecraft mc) {
		if (enabled) {
			disable(mc);
		} else {
			enable(mc);
		}
	}

	public static void enable(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			return;
		}
		savedX = mc.player.getX();
		savedY = mc.player.getY();
		savedZ = mc.player.getZ();

		camera = new Marker(EntityType.MARKER, mc.level);
		camera.setPos(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
		camera.setYRot(mc.player.getYRot());
		camera.setXRot(mc.player.getXRot());
		camera.setOldPosAndRot();

		lastNanos = System.nanoTime();
		enabled = true;
		mc.setCameraEntity(camera);
	}

	public static void disable(Minecraft mc) {
		enabled = false;
		camera = null;
		if (mc.player != null) {
			mc.setCameraEntity(mc.player);
		}
	}

	/** Client tick: keep the real player exactly where it was. */
	public static void tick(Minecraft mc) {
		if (!enabled) {
			return;
		}
		if (mc.player == null || mc.level == null) {
			// Left the world; drop the camera without touching the (gone) player.
			enabled = false;
			camera = null;
			return;
		}
		mc.player.setPos(savedX, savedY, savedZ);
		mc.player.setDeltaMovement(0, 0, 0);
		mc.player.resetFallDistance();
	}

	/** Called every rendered frame: fly the camera and copy the look direction. */
	public static void frame(Minecraft mc) {
		if (!enabled || camera == null || mc.player == null) {
			return;
		}

		long now = System.nanoTime();
		// Elapsed time measured in game ticks (1 tick = 50 ms), capped to avoid jumps after a lag spike.
		double ticks = Math.min(5.0, (now - lastNanos) / 50_000_000.0);
		lastNanos = now;

		// Look where the player looks (mouse turns the player).
		camera.setYRot(mc.player.getYRot());
		camera.setXRot(mc.player.getXRot());

		if (mc.screen == null) {
			Options o = mc.options;
			double forward = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
			double strafe = (o.keyLeft.isDown() ? 1 : 0) - (o.keyRight.isDown() ? 1 : 0);
			double vertical = (o.keyJump.isDown() ? 1 : 0) - (o.keyShift.isDown() ? 1 : 0);

			double yaw = Math.toRadians(camera.getYRot());
			double pitch = Math.toRadians(camera.getXRot());
			// Minecraft: yaw 0 faces +Z, positive pitch looks down.
			double fx = -Math.sin(yaw) * Math.cos(pitch);
			double fy = -Math.sin(pitch);
			double fz = Math.cos(yaw) * Math.cos(pitch);
			double lx = Math.cos(yaw);
			double lz = Math.sin(yaw);

			double mx = fx * forward + lx * strafe;
			double my = fy * forward + vertical;
			double mz = fz * forward + lz * strafe;
			double len = Math.sqrt(mx * mx + my * my + mz * mz);
			if (len > 1.0e-6) {
				double s = PulseConfig.freecamSpeed() * ticks / len;
				camera.setPos(camera.getX() + mx * s, camera.getY() + my * s, camera.getZ() + mz * s);
			}
		}

		// Collapse interpolation: we already update position/rotation every frame.
		camera.setOldPosAndRot();
	}

	private Freecam() {
	}
}
