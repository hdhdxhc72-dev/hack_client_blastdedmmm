package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Lights up dark areas by continuously applying the vanilla Night Vision effect to yourself -
 * the same effect a potion or beacon gives, just kept topped up. On/off state is runtime-only
 * (starts off).
 *
 * This is the mixin-free way to do it. Meteor's "Gamma"/"Luminance" fullbright modes hook
 * directly into the lighting renderer, which needs a mixin Pulse doesn't have yet; Night
 * Vision is a real, server-synced vanilla status effect, so this needs none.
 *
 * Known quirk: if you drink a real Night Vision potion while this is on and then turn this
 * off, it'll also clear the real potion's remaining time (both look identical to the game).
 */
public final class Fullbright {
	public static boolean enabled = false;

	private static boolean wasEnabled = false;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null) {
			return;
		}

		Holder<MobEffect> nightVision = BuiltInRegistries.MOB_EFFECT.wrapAsHolder(MobEffects.NIGHT_VISION.value());

		if (enabled) {
			MobEffectInstance instance = player.getEffect(nightVision);
			if (instance == null || instance.getDuration() < 220) {
				player.addEffect(new MobEffectInstance(nightVision, 420, 0));
			}
		} else if (wasEnabled && player.hasEffect(nightVision)) {
			player.removeEffect(nightVision);
		}
		wasEnabled = enabled;
	}

	private Fullbright() {
	}
}
