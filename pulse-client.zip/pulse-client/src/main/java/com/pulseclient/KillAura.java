package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/**
 * Auto-attacks the nearest valid target within range, once per full attack cooldown, exactly
 * like clicking by hand (no rotation changes). On/off state is runtime-only (starts off).
 *
 * Servers with anti-cheat will kick or ban you for this. Intended for singleplayer and
 * servers where it's allowed.
 */
public final class KillAura {
	public static boolean enabled = false;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (!enabled || player == null || mc.level == null || mc.gameMode == null
				|| mc.screen != null || !player.isAlive() || player.isSpectator()) {
			return;
		}
		// Only swing when the weapon is fully charged (matches a normal full-damage hit).
		if (player.getAttackStrengthScale(0.5f) < 1.0f) {
			return;
		}

		double range = PulseConfig.killauraRange;
		double bestDistSq = range * range;
		Entity best = null;
		for (Entity e : mc.level.getEntities(player, player.getBoundingBox().inflate(range), x -> true)) {
			if (!isValidTarget(e)) {
				continue;
			}
			double d = player.distanceToSqr(e);
			if (d <= bestDistSq) {
				bestDistSq = d;
				best = e;
			}
		}

		if (best != null && Criticals.readyToAttack(mc)) {
			mc.gameMode.attack(player, best);
			player.swing(InteractionHand.MAIN_HAND);
		}
	}

	private static boolean isValidTarget(Entity e) {
		if (!(e instanceof LivingEntity living) || !living.isAlive() || e instanceof ArmorStand || e.isSpectator()) {
			return false;
		}
		if (e instanceof Player) {
			return PulseConfig.killauraPlayers;
		}
		if (e instanceof Enemy) {
			return PulseConfig.killauraHostile;
		}
		if (e instanceof Mob) {
			return PulseConfig.killauraPassive;
		}
		return false;
	}

	private KillAura() {
	}
}
