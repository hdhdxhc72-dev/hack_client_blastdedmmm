package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Creative-style fly and a simple ground/air speed boost.
 * On/off state is runtime-only (always starts off) and is applied once per client tick.
 *
 * Note: servers with anti-cheat (or default "allow-flight=false") will kick or rubber-band
 * you for this. It is intended for singleplayer and servers you control.
 */
public final class Movement {
	public static boolean flyEnabled = false;
	public static boolean speedEnabled = false;

	/** Walking speed in blocks per tick; the speed multiplier scales this. */
	private static final double BASE_SPEED = 0.1;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null || mc.screen != null) {
			return;
		}
		if (!flyEnabled && !speedEnabled) {
			return;
		}

		Options o = mc.options;
		double forward = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
		double strafe = (o.keyLeft.isDown() ? 1 : 0) - (o.keyRight.isDown() ? 1 : 0);

		// Minecraft: yaw 0 faces +Z; "left" is +X at yaw 0.
		double yaw = Math.toRadians(player.getYRot());
		double sin = Math.sin(yaw);
		double cos = Math.cos(yaw);
		double dx = -sin * forward + cos * strafe;
		double dz = cos * forward + sin * strafe;
		double len = Math.sqrt(dx * dx + dz * dz);
		boolean moving = len > 1.0e-6;
		if (moving) {
			dx /= len;
			dz /= len;
		}

		if (flyEnabled) {
			double s = PulseConfig.flySpeed();
			double vy = (o.keyJump.isDown() ? s : 0) - (o.keyShift.isDown() ? s : 0);
			player.setDeltaMovement(moving ? dx * s : 0, vy, moving ? dz * s : 0);
			player.resetFallDistance();
		} else if (moving) {
			double s = BASE_SPEED * PulseConfig.speedMultiplier();
			Vec3 v = player.getDeltaMovement();
			player.setDeltaMovement(dx * s, v.y, dz * s);
		}
	}

	private Movement() {
	}
}
