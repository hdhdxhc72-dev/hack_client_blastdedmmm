package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Fly, speed and freecam: ON/OFF buttons plus buttons that cycle through preset speeds. */
public class MovementScreen extends Screen {
	private final Screen parent;

	public MovementScreen(Screen parent) {
		super(Component.literal("Pulse Client - Movement & Camera"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 220;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		int y = Math.max(30, this.height / 2 - 85);

		this.addRenderableWidget(Button.builder(flyLabel(), (btn) -> {
			Movement.flyEnabled = !Movement.flyEnabled;
			btn.setMessage(flyLabel());
		}).bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(flySpeedLabel(), (btn) -> {
			PulseConfig.flySpeedIndex = (PulseConfig.flySpeedIndex + 1) % PulseConfig.FLY_SPEEDS.length;
			btn.setMessage(flySpeedLabel());
			PulseConfig.save();
		}).bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(speedLabel(), (btn) -> {
			Movement.speedEnabled = !Movement.speedEnabled;
			btn.setMessage(speedLabel());
		}).bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(speedMultLabel(), (btn) -> {
			PulseConfig.speedIndex = (PulseConfig.speedIndex + 1) % PulseConfig.SPEED_MULTS.length;
			btn.setMessage(speedMultLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(freecamLabel(), (btn) -> {
			Freecam.toggle(Minecraft.getInstance());
			btn.setMessage(freecamLabel());
		}).bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(freecamSpeedLabel(), (btn) -> {
			PulseConfig.freecamSpeedIndex = (PulseConfig.freecamSpeedIndex + 1) % PulseConfig.FLY_SPEEDS.length;
			btn.setMessage(freecamSpeedLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 5, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 6 + 6, 150, h)
				.build());
	}

	private static Component flyLabel() {
		return Component.literal("Fly: " + (Movement.flyEnabled ? "ON" : "OFF"));
	}

	private static Component flySpeedLabel() {
		return Component.literal("Fly speed: " + PulseConfig.flySpeed() + " blocks/tick (click to change)");
	}

	private static Component speedLabel() {
		return Component.literal("Speed: " + (Movement.speedEnabled ? "ON" : "OFF"));
	}

	private static Component speedMultLabel() {
		return Component.literal("Speed multiplier: x" + PulseConfig.speedMultiplier() + " (click to change)");
	}

	private static Component freecamLabel() {
		return Component.literal("Freecam: " + (Freecam.enabled ? "ON" : "OFF"));
	}

	private static Component freecamSpeedLabel() {
		return Component.literal("Freecam speed: " + PulseConfig.freecamSpeed() + " blocks/tick (click to change)");
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
