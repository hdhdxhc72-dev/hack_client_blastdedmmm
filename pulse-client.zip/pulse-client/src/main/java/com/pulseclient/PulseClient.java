package com.pulseclient;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionEvents;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

public class PulseClient implements ClientModInitializer {
	public static final String MOD_ID = "pulseclient";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyMapping toggleHudKey;
	private static KeyMapping toggleCoordsKey;
	private static KeyMapping zoomKey;
	private static KeyMapping toggleEspKey;
	private static KeyMapping espMenuKey;
	private static KeyMapping toggleXrayKey;
	private static KeyMapping toggleFlyKey;
	private static KeyMapping toggleSpeedKey;
	private static KeyMapping toggleFreecamKey;
	private static KeyMapping toggleKillAuraKey;
	private static KeyMapping toggleReachKey;
	private static KeyMapping toggleAutoTotemKey;
	private static KeyMapping toggleCriticalsKey;
	private static KeyMapping toggleAntiKnockbackKey;
	private static KeyMapping toggleAutoSprintKey;
	private static KeyMapping toggleTriggerBotKey;
	private static KeyMapping toggleAutoRespawnKey;
	private static KeyMapping toggleAntiAfkKey;
	private static KeyMapping toggleFullbrightKey;
	private static KeyMapping toggleAutoEatKey;

	private static int tickCounter = 0;

	// Zoom state: the player's real FOV, saved while the zoom key is held.
	private static Integer savedFov = null;

	// Simple FPS counter driven by HUD frames.
	private static long fpsWindowStart = System.nanoTime();
	private static int fpsFrames = 0;
	private static int fps = 0;

	@Override
	public void onInitializeClient() {
		PulseConfig.load();

		if (PulseConfig.autoCheckUpdates) {
			Updater.checkNow();
		}

		KeyMapping.Category category = KeyMapping.Category.register(
				Identifier.fromNamespaceAndPath(MOD_ID, "main"));

		toggleHudKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_hud", InputConstants.Type.KEYSYM, InputConstants.KEY_H, category));
		toggleCoordsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_coords", InputConstants.Type.KEYSYM, InputConstants.KEY_G, category));
		zoomKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.zoom", InputConstants.Type.KEYSYM, InputConstants.KEY_C, category));

		toggleEspKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_esp", InputConstants.Type.KEYSYM, InputConstants.KEY_K, category));

		espMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.esp_menu", InputConstants.Type.KEYSYM, InputConstants.KEY_INSERT, category));
		toggleXrayKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_xray", InputConstants.Type.KEYSYM, InputConstants.KEY_X, category));
		toggleFlyKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_fly", InputConstants.Type.KEYSYM, InputConstants.KEY_V, category));
		toggleSpeedKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_speed", InputConstants.Type.KEYSYM, InputConstants.KEY_B, category));
		toggleFreecamKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_freecam", InputConstants.Type.KEYSYM, InputConstants.KEY_N, category));
		toggleKillAuraKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_killaura", InputConstants.Type.KEYSYM, InputConstants.KEY_R, category));
		toggleReachKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_reach", InputConstants.Type.KEYSYM, InputConstants.KEY_J, category));
		toggleAutoTotemKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_autototem", InputConstants.Type.KEYSYM, InputConstants.KEY_SEMICOLON, category));
		toggleCriticalsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_criticals", InputConstants.Type.KEYSYM, InputConstants.KEY_APOSTROPHE, category));
		toggleAntiKnockbackKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_antiknockback", InputConstants.Type.KEYSYM, InputConstants.KEY_LEFT_BRACKET, category));
		toggleAutoSprintKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_autosprint", InputConstants.Type.KEYSYM, InputConstants.KEY_RIGHT_BRACKET, category));
		toggleTriggerBotKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_triggerbot", InputConstants.Type.KEYSYM, InputConstants.KEY_PERIOD, category));
		toggleAutoRespawnKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_autorespawn", InputConstants.Type.KEYSYM, InputConstants.KEY_SLASH, category));
		toggleAntiAfkKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_antiafk", InputConstants.Type.KEYSYM, InputConstants.KEY_COMMA, category));
		toggleFullbrightKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_fullbright", InputConstants.Type.KEYSYM, InputConstants.KEY_O, category));
		toggleAutoEatKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.pulseclient.toggle_autoeat", InputConstants.Type.KEYSYM, InputConstants.KEY_P, category));

		EspRenderer.init();

		// Runs once per rendered frame: keeps the freecam camera smooth.
		LevelExtractionEvents.END_EXTRACTION.register(context -> Freecam.frame(Minecraft.getInstance()));

		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(MOD_ID, "info_hud"), PulseClient::renderHud);

		ClientTickEvents.END_CLIENT_TICK.register(PulseClient::onTick);

		// Make sure a held zoom never gets written into options.txt on shutdown.
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			restoreFov(client);
			EspRenderer.close();
		});

		LOGGER.info("Pulse Client loaded");
	}

	private static void onTick(Minecraft client) {
		while (toggleHudKey.consumeClick()) {
			PulseConfig.hudEnabled = !PulseConfig.hudEnabled;
			PulseConfig.save();
		}
		while (toggleCoordsKey.consumeClick()) {
			PulseConfig.showCoords = !PulseConfig.showCoords;
			PulseConfig.save();
		}

		while (toggleEspKey.consumeClick()) {
			PulseConfig.espEnabled = !PulseConfig.espEnabled;
			PulseConfig.save();
			EspScanner.scanBlocks(client); // refresh (or clear) immediately
		}
		while (espMenuKey.consumeClick()) {
			if (client.screen == null && client.player != null) {
				client.gui.setScreen(new PulseMenu());
			}
		}
		while (toggleXrayKey.consumeClick()) {
			PulseConfig.xrayEnabled = !PulseConfig.xrayEnabled;
			EspScanner.scanOres(client);
		}
		while (toggleFlyKey.consumeClick()) {
			Movement.flyEnabled = !Movement.flyEnabled;
		}
		while (toggleSpeedKey.consumeClick()) {
			Movement.speedEnabled = !Movement.speedEnabled;
		}

		// Rescan nearby block entities (chests, spawners...) about 4 times per second,
		// and ores (X-ray) about once per second.
		tickCounter++;
		if (tickCounter % 5 == 0) {
			EspScanner.scanBlocks(client);
		}
		if (tickCounter % 20 == 0) {
			EspScanner.scanOres(client);
		}

		while (toggleFreecamKey.consumeClick()) {
			Freecam.toggle(client);
		}

		while (toggleKillAuraKey.consumeClick()) {
			KillAura.enabled = !KillAura.enabled;
		}

		while (toggleReachKey.consumeClick()) {
			Reach.enabled = !Reach.enabled;
		}
		while (toggleAutoTotemKey.consumeClick()) {
			AutoTotem.enabled = !AutoTotem.enabled;
		}
		while (toggleCriticalsKey.consumeClick()) {
			Criticals.enabled = !Criticals.enabled;
		}
		while (toggleAntiKnockbackKey.consumeClick()) {
			AntiKnockback.enabled = !AntiKnockback.enabled;
		}
		while (toggleAutoSprintKey.consumeClick()) {
			AutoSprint.enabled = !AutoSprint.enabled;
		}
		while (toggleTriggerBotKey.consumeClick()) {
			TriggerBot.enabled = !TriggerBot.enabled;
		}
		while (toggleAutoRespawnKey.consumeClick()) {
			AutoRespawn.enabled = !AutoRespawn.enabled;
		}
		while (toggleAntiAfkKey.consumeClick()) {
			AntiAFK.enabled = !AntiAFK.enabled;
		}
		while (toggleFullbrightKey.consumeClick()) {
			Fullbright.enabled = !Fullbright.enabled;
		}
		while (toggleAutoEatKey.consumeClick()) {
			AutoEat.enabled = !AutoEat.enabled;
		}

		Movement.tick(client);
		Reach.tick(client);
		KillAura.tick(client);
		Freecam.tick(client);
		AutoTotem.tick(client);
		AntiKnockback.tick(client);
		AutoSprint.tick(client);
		TriggerBot.tick(client);
		AutoRespawn.tick(client);
		AntiAFK.tick(client);
		Fullbright.tick(client);
		AutoEat.tick(client);

		boolean zooming = client.player != null && client.screen == null
				&& PulseConfig.zoomEnabled && zoomKey.isDown();
		if (zooming) {
			if (savedFov == null) {
				savedFov = client.options.fov().get();
			}
			client.options.fov().set(PulseConfig.zoomFov);
		} else {
			restoreFov(client);
		}
	}

	private static void restoreFov(Minecraft client) {
		if (savedFov != null) {
			client.options.fov().set(savedFov);
			savedFov = null;
		}
	}

	private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		// FPS bookkeeping runs every frame, even when the HUD is hidden.
		fpsFrames++;
		long now = System.nanoTime();
		if (now - fpsWindowStart >= 1_000_000_000L) {
			fps = fpsFrames;
			fpsFrames = 0;
			fpsWindowStart = now;
		}

		Minecraft mc = Minecraft.getInstance();
		if (!PulseConfig.hudEnabled || mc.options.hideGui || mc.player == null) {
			return;
		}

		List<String> lines = new ArrayList<>();
		if (PulseConfig.showFps) {
			lines.add("FPS: " + fps);
		}
		if (PulseConfig.showCoords) {
			lines.add(String.format("XYZ: %.1f / %.1f / %.1f",
					mc.player.getX(), mc.player.getY(), mc.player.getZ()));
		}
		if (PulseConfig.showFacing) {
			String dir = mc.player.getDirection().getSerializedName();
			lines.add("Facing: " + Character.toUpperCase(dir.charAt(0)) + dir.substring(1));
		}

		if (PulseConfig.espEnabled) {
			lines.add("ESP: ON");
		}
		if (PulseConfig.xrayEnabled) {
			lines.add("X-Ray: ON");
		}
		if (Movement.flyEnabled) {
			lines.add("Fly: ON");
		}
		if (Movement.speedEnabled) {
			lines.add("Speed: x" + PulseConfig.speedMultiplier());
		}
		if (Freecam.enabled) {
			lines.add("Freecam: ON");
		}
		if (KillAura.enabled) {
			lines.add("KillAura: ON");
		}
		if (Reach.enabled) {
			lines.add("Reach: " + PulseConfig.reachEntity());
		}
		if (AutoTotem.enabled) {
			lines.add("AutoTotem: ON");
		}
		if (Criticals.enabled) {
			lines.add("Criticals: ON");
		}
		if (AntiKnockback.enabled) {
			lines.add("AntiKB: ON");
		}
		if (AutoSprint.enabled) {
			lines.add("AutoSprint: ON");
		}
		if (TriggerBot.enabled) {
			lines.add("TriggerBot: ON");
		}
		if (AutoRespawn.enabled) {
			lines.add("AutoRespawn: ON");
		}
		if (AntiAFK.enabled) {
			lines.add("AntiAFK: ON");
		}
		if (Fullbright.enabled) {
			lines.add("Fullbright: ON");
		}
		if (AutoEat.enabled) {
			lines.add("AutoEat: ON");
		}
		if (Updater.state == Updater.State.UPDATE_AVAILABLE) {
			lines.add("Update available: v" + Updater.latestVersion + " (Insert > Updates)");
		} else if (Updater.state == Updater.State.DOWNLOADED) {
			lines.add("Update downloaded - restart to use it");
		}

		Font font = mc.font;
		int y = 4;
		for (String line : lines) {
			graphics.text(font, line, 4, y, 0xFFFFFFFF, true);
			y += font.lineHeight + 2;
		}
	}
}
