package com.pulseclient;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Tiny properties-file config stored in the game's config folder
 * (config/pulseclient.properties). Edit it by hand or use the in-game keys.
 */
public final class PulseConfig {
	// ---- Info HUD ----
	public static boolean hudEnabled = true;
	public static boolean showFps = true;
	public static boolean showCoords = true;
	public static boolean showFacing = true;
	/** FOV used while the zoom key is held. Vanilla's FOV slider range is 30-110. */
	public static int zoomFov = 30;

	// ---- ESP (off by default; see README warning about multiplayer servers) ----
	public static boolean espEnabled = false;
	public static boolean espPlayers = true;
	public static boolean espHostile = true;
	public static boolean espPassive = false;
	public static boolean espItems = true;
	public static boolean espChests = true;
	public static boolean espTrappedChests = true;
	public static boolean espEnderChests = true;
	public static boolean espBarrels = true;
	public static boolean espShulkers = true;
	public static boolean espSpawners = true;
	public static boolean espOtherStorage = false;
	/** Max distance (blocks) for entity ESP. */
	public static int espEntityRange = 96;
	/** Chunk radius scanned for block ESP (chests, spawners...). */
	public static int espChunkRadius = 8;
	/** Box opacity in percent (5-100). */
	public static int espAlphaPercent = 35;

	// ---- X-Ray (ore highlighter). The master switch is NOT saved: it starts off every launch. ----
	public static boolean xrayEnabled = false;
	public static boolean xrayCoal = false;
	public static boolean xrayIron = true;
	public static boolean xrayCopper = false;
	public static boolean xrayGold = true;
	public static boolean xrayRedstone = false;
	public static boolean xrayLapis = false;
	public static boolean xrayDiamond = true;
	public static boolean xrayEmerald = true;
	public static boolean xrayQuartz = false;
	public static boolean xrayDebris = true;
	/** Scan radius in blocks around the player (8-32). Bigger costs more CPU. */
	public static int xrayRadius = 16;

	// ---- Movement. Fly/speed on-off state lives in Movement and is NOT saved. ----
	public static final double[] FLY_SPEEDS = {0.25, 0.5, 1.0, 2.0}; // blocks per tick
	public static final double[] SPEED_MULTS = {1.5, 2.0, 3.0, 5.0};
	public static int flySpeedIndex = 1;
	public static int speedIndex = 1;
	public static int freecamSpeedIndex = 1;

	// ---- Kill Aura. The on/off state lives in KillAura and is NOT saved (starts off). ----
	public static int killauraRange = 3; // blocks, 3-6
	public static boolean killauraPlayers = false;
	public static boolean killauraHostile = true;
	public static boolean killauraPassive = false;

	// ---- Reach. The on/off state lives in Reach and is NOT saved (starts off). ----
	public static final double[] REACH_ENTITY = {3.5, 4.0, 5.0, 6.0};
	public static final double[] REACH_BLOCK = {5.0, 5.5, 6.0, 7.0};
	public static int reachIndex = 1;

	public static double reachEntity() {
		return REACH_ENTITY[Math.max(0, Math.min(REACH_ENTITY.length - 1, reachIndex))];
	}

	public static double reachBlock() {
		return REACH_BLOCK[Math.max(0, Math.min(REACH_BLOCK.length - 1, reachIndex))];
	}

	// ---- Zoom (the hold-to-zoom key only works while this is on) ----
	public static boolean zoomEnabled = true;

	// ---- Auto Totem. The on/off state lives in AutoTotem and is NOT saved (starts off). ----
	/** Swap when health + absorption drops to or below this (2-20, in half-heart steps of 2 = 1 heart). */
	public static double autoTotemHealth = 10.0;

	// ---- Criticals. The on/off state lives in Criticals and is NOT saved (starts off). No extra settings. ----

	// ---- Anti-Knockback. The on/off state lives in AntiKnockback and is NOT saved (starts off). ----
	public static final double[] ANTIKB_STRENGTHS = {0.25, 0.5, 0.75, 1.0};
	public static int antiKnockbackIndex = 1;

	public static double antiKnockbackStrength() {
		return ANTIKB_STRENGTHS[Math.max(0, Math.min(ANTIKB_STRENGTHS.length - 1, antiKnockbackIndex))];
	}

	// ---- Auto Sprint. The on/off state lives in AutoSprint and is NOT saved (starts off). No extra settings. ----

	// ---- Trigger Bot. The on/off state lives in TriggerBot and is NOT saved (starts off). ----
	public static boolean triggerbotPlayers = false;
	public static boolean triggerbotHostile = true;
	public static boolean triggerbotPassive = false;

	// ---- Auto Respawn, Anti-AFK, Fullbright. On/off state lives in their own classes, NOT saved. No extra settings. ----

	// ---- Auto Eat. The on/off state lives in AutoEat and is NOT saved (starts off). ----
	/** Start eating when hunger drops to or below this (1-19). */
	public static int autoEatHunger = 16;

	// ---- Updates (checks a GitHub repo's Releases; see Updater.java). ----
	/** "owner/repo" of the GitHub repo to check for releases. Empty = never contacted. */
	public static String updateRepo = "";
	public static boolean autoCheckUpdates = true;

	public static double freecamSpeed() {
		return FLY_SPEEDS[Math.max(0, Math.min(FLY_SPEEDS.length - 1, freecamSpeedIndex))];
	}

	public static double flySpeed() {
		return FLY_SPEEDS[Math.max(0, Math.min(FLY_SPEEDS.length - 1, flySpeedIndex))];
	}

	public static double speedMultiplier() {
		return SPEED_MULTS[Math.max(0, Math.min(SPEED_MULTS.length - 1, speedIndex))];
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("pulseclient.properties");
	}

	public static void load() {
		Path file = path();
		if (!Files.exists(file)) {
			save();
			return;
		}
		Properties p = new Properties();
		try (Reader reader = Files.newBufferedReader(file)) {
			p.load(reader);
		} catch (IOException e) {
			PulseClient.LOGGER.warn("Could not read {}, using defaults", file, e);
			return;
		}
		hudEnabled = bool(p, "hudEnabled", hudEnabled);
		showFps = bool(p, "showFps", showFps);
		showCoords = bool(p, "showCoords", showCoords);
		showFacing = bool(p, "showFacing", showFacing);
		zoomFov = clamp(integer(p, "zoomFov", zoomFov), 30, 110);

		espEnabled = bool(p, "espEnabled", espEnabled);
		espPlayers = bool(p, "espPlayers", espPlayers);
		espHostile = bool(p, "espHostile", espHostile);
		espPassive = bool(p, "espPassive", espPassive);
		espItems = bool(p, "espItems", espItems);
		espChests = bool(p, "espChests", espChests);
		espTrappedChests = bool(p, "espTrappedChests", espTrappedChests);
		espEnderChests = bool(p, "espEnderChests", espEnderChests);
		espBarrels = bool(p, "espBarrels", espBarrels);
		espShulkers = bool(p, "espShulkers", espShulkers);
		espSpawners = bool(p, "espSpawners", espSpawners);
		espOtherStorage = bool(p, "espOtherStorage", espOtherStorage);
		espEntityRange = clamp(integer(p, "espEntityRange", espEntityRange), 8, 256);
		espChunkRadius = clamp(integer(p, "espChunkRadius", espChunkRadius), 1, 16);
		espAlphaPercent = clamp(integer(p, "espAlphaPercent", espAlphaPercent), 5, 100);

		xrayCoal = bool(p, "xrayCoal", xrayCoal);
		xrayIron = bool(p, "xrayIron", xrayIron);
		xrayCopper = bool(p, "xrayCopper", xrayCopper);
		xrayGold = bool(p, "xrayGold", xrayGold);
		xrayRedstone = bool(p, "xrayRedstone", xrayRedstone);
		xrayLapis = bool(p, "xrayLapis", xrayLapis);
		xrayDiamond = bool(p, "xrayDiamond", xrayDiamond);
		xrayEmerald = bool(p, "xrayEmerald", xrayEmerald);
		xrayQuartz = bool(p, "xrayQuartz", xrayQuartz);
		xrayDebris = bool(p, "xrayDebris", xrayDebris);
		xrayRadius = clamp(integer(p, "xrayRadius", xrayRadius), 8, 32);
		flySpeedIndex = clamp(integer(p, "flySpeedIndex", flySpeedIndex), 0, FLY_SPEEDS.length - 1);
		speedIndex = clamp(integer(p, "speedIndex", speedIndex), 0, SPEED_MULTS.length - 1);
		freecamSpeedIndex = clamp(integer(p, "freecamSpeedIndex", freecamSpeedIndex), 0, FLY_SPEEDS.length - 1);
		zoomEnabled = bool(p, "zoomEnabled", zoomEnabled);
		reachIndex = clamp(integer(p, "reachIndex", reachIndex), 0, REACH_ENTITY.length - 1);
		killauraRange = clamp(integer(p, "killauraRange", killauraRange), 3, 6);
		killauraPlayers = bool(p, "killauraPlayers", killauraPlayers);
		killauraHostile = bool(p, "killauraHostile", killauraHostile);
		killauraPassive = bool(p, "killauraPassive", killauraPassive);

		autoTotemHealth = clamp(integer(p, "autoTotemHealth", (int) autoTotemHealth), 2, 20);
		antiKnockbackIndex = clamp(integer(p, "antiKnockbackIndex", antiKnockbackIndex), 0, ANTIKB_STRENGTHS.length - 1);
		triggerbotPlayers = bool(p, "triggerbotPlayers", triggerbotPlayers);
		triggerbotHostile = bool(p, "triggerbotHostile", triggerbotHostile);
		triggerbotPassive = bool(p, "triggerbotPassive", triggerbotPassive);
		autoEatHunger = clamp(integer(p, "autoEatHunger", autoEatHunger), 1, 19);
		updateRepo = p.getProperty("updateRepo", updateRepo);
		autoCheckUpdates = bool(p, "autoCheckUpdates", autoCheckUpdates);
	}

	public static void save() {
		Properties p = new Properties();
		p.setProperty("hudEnabled", Boolean.toString(hudEnabled));
		p.setProperty("showFps", Boolean.toString(showFps));
		p.setProperty("showCoords", Boolean.toString(showCoords));
		p.setProperty("showFacing", Boolean.toString(showFacing));
		p.setProperty("zoomFov", Integer.toString(zoomFov));

		p.setProperty("espEnabled", Boolean.toString(espEnabled));
		p.setProperty("espPlayers", Boolean.toString(espPlayers));
		p.setProperty("espHostile", Boolean.toString(espHostile));
		p.setProperty("espPassive", Boolean.toString(espPassive));
		p.setProperty("espItems", Boolean.toString(espItems));
		p.setProperty("espChests", Boolean.toString(espChests));
		p.setProperty("espTrappedChests", Boolean.toString(espTrappedChests));
		p.setProperty("espEnderChests", Boolean.toString(espEnderChests));
		p.setProperty("espBarrels", Boolean.toString(espBarrels));
		p.setProperty("espShulkers", Boolean.toString(espShulkers));
		p.setProperty("espSpawners", Boolean.toString(espSpawners));
		p.setProperty("espOtherStorage", Boolean.toString(espOtherStorage));
		p.setProperty("espEntityRange", Integer.toString(espEntityRange));
		p.setProperty("espChunkRadius", Integer.toString(espChunkRadius));
		p.setProperty("espAlphaPercent", Integer.toString(espAlphaPercent));

		p.setProperty("xrayCoal", Boolean.toString(xrayCoal));
		p.setProperty("xrayIron", Boolean.toString(xrayIron));
		p.setProperty("xrayCopper", Boolean.toString(xrayCopper));
		p.setProperty("xrayGold", Boolean.toString(xrayGold));
		p.setProperty("xrayRedstone", Boolean.toString(xrayRedstone));
		p.setProperty("xrayLapis", Boolean.toString(xrayLapis));
		p.setProperty("xrayDiamond", Boolean.toString(xrayDiamond));
		p.setProperty("xrayEmerald", Boolean.toString(xrayEmerald));
		p.setProperty("xrayQuartz", Boolean.toString(xrayQuartz));
		p.setProperty("xrayDebris", Boolean.toString(xrayDebris));
		p.setProperty("xrayRadius", Integer.toString(xrayRadius));
		p.setProperty("flySpeedIndex", Integer.toString(flySpeedIndex));
		p.setProperty("speedIndex", Integer.toString(speedIndex));
		p.setProperty("freecamSpeedIndex", Integer.toString(freecamSpeedIndex));
		p.setProperty("zoomEnabled", Boolean.toString(zoomEnabled));
		p.setProperty("reachIndex", Integer.toString(reachIndex));
		p.setProperty("killauraRange", Integer.toString(killauraRange));
		p.setProperty("killauraPlayers", Boolean.toString(killauraPlayers));
		p.setProperty("killauraHostile", Boolean.toString(killauraHostile));
		p.setProperty("killauraPassive", Boolean.toString(killauraPassive));

		p.setProperty("autoTotemHealth", Integer.toString((int) autoTotemHealth));
		p.setProperty("antiKnockbackIndex", Integer.toString(antiKnockbackIndex));
		p.setProperty("triggerbotPlayers", Boolean.toString(triggerbotPlayers));
		p.setProperty("triggerbotHostile", Boolean.toString(triggerbotHostile));
		p.setProperty("triggerbotPassive", Boolean.toString(triggerbotPassive));
		p.setProperty("autoEatHunger", Integer.toString(autoEatHunger));
		p.setProperty("updateRepo", updateRepo == null ? "" : updateRepo);
		p.setProperty("autoCheckUpdates", Boolean.toString(autoCheckUpdates));
		try (Writer writer = Files.newBufferedWriter(path())) {
			p.store(writer, "Pulse Client settings");
		} catch (IOException e) {
			PulseClient.LOGGER.warn("Could not save config", e);
		}
	}

	private static boolean bool(Properties p, String key, boolean fallback) {
		String v = p.getProperty(key);
		return v == null ? fallback : Boolean.parseBoolean(v.trim());
	}

	private static int integer(Properties p, String key, int fallback) {
		try {
			String v = p.getProperty(key);
			return v == null ? fallback : Integer.parseInt(v.trim());
		} catch (NumberFormatException e) {
			return fallback;
		}
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	private PulseConfig() {
	}
}
