package com.pulseclient;

import java.util.List;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Main menu (default key: O). Opens the ESP, X-Ray and Movement settings screens. */
public class PulseMenu extends Screen {
	public PulseMenu() {
		super(Component.literal("Pulse Client"));
	}

	@Override
	protected void init() {
		final int w = 260;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		int y = Math.max(30, this.height / 2 - 130);

		this.addRenderableWidget(Button.builder(Component.literal("HUD & Zoom"),
				(btn) -> this.minecraft.gui.setScreen(hudScreen(this)))
				.bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("ESP Settings"),
				(btn) -> this.minecraft.gui.setScreen(espScreen(this)))
				.bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("X-Ray (Ore) Settings"),
				(btn) -> this.minecraft.gui.setScreen(xrayScreen(this)))
				.bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Movement & Camera (Fly / Speed / Freecam)"),
				(btn) -> this.minecraft.gui.setScreen(new MovementScreen(this)))
				.bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Combat (Kill Aura / Reach)"),
				(btn) -> this.minecraft.gui.setScreen(new CombatScreen(this)))
				.bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Combat Extras (Totem / Crits / Anti-KB / Sprint / Trigger)"),
				(btn) -> this.minecraft.gui.setScreen(new CombatExtrasScreen(this)))
				.bounds(x, y + step * 5, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Utility (Respawn / Anti-AFK / Fullbright / Auto Eat)"),
				(btn) -> this.minecraft.gui.setScreen(new UtilityScreen(this)))
				.bounds(x, y + step * 6, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("World Seed (singleplayer)"),
				(btn) -> this.minecraft.gui.setScreen(new SeedScreen(this)))
				.bounds(x, y + step * 7, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Updates"),
				(btn) -> this.minecraft.gui.setScreen(new UpdateScreen(this)))
				.bounds(x, y + step * 8, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 9 + 6, 150, h).build());
	}

	private static ToggleScreen hudScreen(Screen parent) {
		return new ToggleScreen(parent, "Pulse Client - HUD & Zoom",
				new ToggleScreen.Toggle("Info HUD (master)", () -> PulseConfig.hudEnabled, v -> PulseConfig.hudEnabled = v),
				List.of(
						new ToggleScreen.Toggle("FPS", () -> PulseConfig.showFps, v -> PulseConfig.showFps = v),
						new ToggleScreen.Toggle("Coordinates", () -> PulseConfig.showCoords, v -> PulseConfig.showCoords = v),
						new ToggleScreen.Toggle("Facing", () -> PulseConfig.showFacing, v -> PulseConfig.showFacing = v),
						new ToggleScreen.Toggle("Zoom (hold key)", () -> PulseConfig.zoomEnabled, v -> PulseConfig.zoomEnabled = v)));
	}

	private static ToggleScreen espScreen(Screen parent) {
		return new ToggleScreen(parent, "Pulse Client - ESP",
				new ToggleScreen.Toggle("ESP (master)", () -> PulseConfig.espEnabled, v -> PulseConfig.espEnabled = v),
				List.of(
						new ToggleScreen.Toggle("Players", () -> PulseConfig.espPlayers, v -> PulseConfig.espPlayers = v),
						new ToggleScreen.Toggle("Hostile mobs", () -> PulseConfig.espHostile, v -> PulseConfig.espHostile = v),
						new ToggleScreen.Toggle("Passive mobs", () -> PulseConfig.espPassive, v -> PulseConfig.espPassive = v),
						new ToggleScreen.Toggle("Dropped items", () -> PulseConfig.espItems, v -> PulseConfig.espItems = v),
						new ToggleScreen.Toggle("Chests", () -> PulseConfig.espChests, v -> PulseConfig.espChests = v),
						new ToggleScreen.Toggle("Trapped chests", () -> PulseConfig.espTrappedChests, v -> PulseConfig.espTrappedChests = v),
						new ToggleScreen.Toggle("Ender chests", () -> PulseConfig.espEnderChests, v -> PulseConfig.espEnderChests = v),
						new ToggleScreen.Toggle("Barrels", () -> PulseConfig.espBarrels, v -> PulseConfig.espBarrels = v),
						new ToggleScreen.Toggle("Shulker boxes", () -> PulseConfig.espShulkers, v -> PulseConfig.espShulkers = v),
						new ToggleScreen.Toggle("Spawners", () -> PulseConfig.espSpawners, v -> PulseConfig.espSpawners = v),
						new ToggleScreen.Toggle("Other storage", () -> PulseConfig.espOtherStorage, v -> PulseConfig.espOtherStorage = v)));
	}

	private static ToggleScreen xrayScreen(Screen parent) {
		return new ToggleScreen(parent, "Pulse Client - X-Ray (Ores)",
				new ToggleScreen.Toggle("X-Ray (master)", () -> PulseConfig.xrayEnabled, v -> PulseConfig.xrayEnabled = v),
				List.of(
						new ToggleScreen.Toggle("Coal", () -> PulseConfig.xrayCoal, v -> PulseConfig.xrayCoal = v),
						new ToggleScreen.Toggle("Iron", () -> PulseConfig.xrayIron, v -> PulseConfig.xrayIron = v),
						new ToggleScreen.Toggle("Copper", () -> PulseConfig.xrayCopper, v -> PulseConfig.xrayCopper = v),
						new ToggleScreen.Toggle("Gold", () -> PulseConfig.xrayGold, v -> PulseConfig.xrayGold = v),
						new ToggleScreen.Toggle("Redstone", () -> PulseConfig.xrayRedstone, v -> PulseConfig.xrayRedstone = v),
						new ToggleScreen.Toggle("Lapis", () -> PulseConfig.xrayLapis, v -> PulseConfig.xrayLapis = v),
						new ToggleScreen.Toggle("Diamond", () -> PulseConfig.xrayDiamond, v -> PulseConfig.xrayDiamond = v),
						new ToggleScreen.Toggle("Emerald", () -> PulseConfig.xrayEmerald, v -> PulseConfig.xrayEmerald = v),
						new ToggleScreen.Toggle("Quartz", () -> PulseConfig.xrayQuartz, v -> PulseConfig.xrayQuartz = v),
						new ToggleScreen.Toggle("Ancient debris", () -> PulseConfig.xrayDebris, v -> PulseConfig.xrayDebris = v)));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}
}
