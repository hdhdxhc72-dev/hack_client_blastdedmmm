package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Raises your client-side attack and block interaction range. Turning it off restores the
 * values the game had. On/off state is runtime-only (starts off).
 *
 * IMPORTANT: this only changes what your client will TRY. The server checks every hit and
 * block break against its own range (vanilla: about 3 blocks for attacks plus a small
 * buffer), so large values are ignored or flagged by anti-cheat.
 */
public final class Reach {
	public static boolean enabled = false;

	private static boolean applied = false;
	private static double originalEntity = 3.0;
	private static double originalBlock = 4.5;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null) {
			applied = false;
			return;
		}
		AttributeInstance entityRange = player.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
		AttributeInstance blockRange = player.getAttribute(Attributes.BLOCK_INTERACTION_RANGE);
		if (entityRange == null || blockRange == null) {
			return;
		}

		if (enabled) {
			if (!applied) {
				originalEntity = entityRange.getBaseValue();
				originalBlock = blockRange.getBaseValue();
				applied = true;
			}
			entityRange.setBaseValue(PulseConfig.reachEntity());
			blockRange.setBaseValue(PulseConfig.reachBlock());
		} else if (applied) {
			entityRange.setBaseValue(originalEntity);
			blockRange.setBaseValue(originalBlock);
			applied = false;
		}
	}

	private Reach() {
	}
}
