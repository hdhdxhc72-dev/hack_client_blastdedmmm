package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * "Get seed" screen.
 *
 * This is NOT a seed cracker. In singleplayer the game already knows the world seed, so we
 * just read and show it. On a multiplayer server the client never receives the seed; a real
 * cracker (e.g. the SeedcrackerX mod) has to work it out from data you collect by exploring.
 */
public class SeedScreen extends Screen {
	private final Screen parent;
	private String status = "Press \"Get seed\".";
	private Long lastSeed = null;

	public SeedScreen(Screen parent) {
		super(Component.literal("Pulse Client - World Seed"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 200;
		final int h = 20;
		int x = this.width / 2 - w / 2;
		int y = Math.max(40, this.height / 2 - 40);

		this.addRenderableWidget(Button.builder(Component.literal("Get seed"), (btn) -> fetchSeed())
				.bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Copy seed"), (btn) -> copySeed())
				.bounds(x, y + 24, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + 56, 150, h).build());
	}

	private void fetchSeed() {
		Minecraft mc = Minecraft.getInstance();
		var server = mc.getSingleplayerServer();
		if (server == null) {
			lastSeed = null;
			status = "Not in singleplayer: the server never sends its seed. Use SeedcrackerX and explore.";
			return;
		}
		try {
			lastSeed = server.overworld().getSeed();
			status = "Seed: " + lastSeed;
		} catch (RuntimeException e) {
			lastSeed = null;
			status = "Could not read the seed (" + e.getClass().getSimpleName() + ").";
			PulseClient.LOGGER.warn("Seed lookup failed", e);
		}
	}

	private void copySeed() {
		if (lastSeed == null) {
			status = "Nothing to copy yet. Press \"Get seed\" first (singleplayer only).";
			return;
		}
		Minecraft.getInstance().keyboardHandler.setClipboard(Long.toString(lastSeed));
		status = "Copied seed " + lastSeed + " to the clipboard.";
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
		graphics.text(this.font, status, this.width / 2 - this.font.width(status) / 2,
				Math.max(40, this.height / 2 - 40) - 16, 0xFFFFFF55, true);
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(parent);
	}
}
