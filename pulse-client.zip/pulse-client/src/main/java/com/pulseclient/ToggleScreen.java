package com.pulseclient;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Reusable settings screen: an optional master switch across the top, then an ON/OFF
 * button for every entry in two columns. Changes apply instantly and are saved.
 */
public class ToggleScreen extends Screen {
	public record Toggle(String label, BooleanSupplier getter, Consumer<Boolean> setter) {
	}

	private final Screen parent;
	private final Toggle master; // may be null
	private final List<Toggle> toggles;

	public ToggleScreen(Screen parent, String title, Toggle master, List<Toggle> toggles) {
		super(Component.literal(title));
		this.parent = parent;
		this.master = master;
		this.toggles = toggles;
	}

	@Override
	protected void init() {
		final int colWidth = 150;
		final int gap = 10;
		final int height = 20;
		final int rowGap = 4;

		int rows = (master != null ? 1 : 0) + (toggles.size() + 1) / 2 + 1; // master + rows + done
		int totalHeight = rows * (height + rowGap);
		int top = Math.max(30, this.height / 2 - totalHeight / 2);
		int left = this.width / 2 - colWidth - gap / 2;
		int fullWidth = colWidth * 2 + gap;

		int y0 = top;
		if (master != null) {
			addToggle(master, left, top, fullWidth);
			y0 = top + height + rowGap;
		}

		for (int i = 0; i < toggles.size(); i++) {
			int col = i % 2;
			int row = i / 2;
			addToggle(toggles.get(i),
					left + col * (colWidth + gap),
					y0 + row * (height + rowGap),
					colWidth);
		}

		int doneY = y0 + ((toggles.size() + 1) / 2) * (height + rowGap) + rowGap;
		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, doneY, 150, height)
				.build());
	}

	private void addToggle(Toggle toggle, int x, int y, int width) {
		Button button = Button.builder(label(toggle), (btn) -> {
			toggle.setter().accept(!toggle.getter().getAsBoolean());
			btn.setMessage(label(toggle));
			PulseConfig.save();
			// Apply right away instead of waiting for the next scan.
			Minecraft mc = Minecraft.getInstance();
			EspScanner.scanBlocks(mc);
			EspScanner.scanOres(mc);
		}).bounds(x, y, width, 20).build();
		this.addRenderableWidget(button);
	}

	private static Component label(Toggle toggle) {
		boolean on = toggle.getter().getAsBoolean();
		return Component.literal(toggle.label() + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
