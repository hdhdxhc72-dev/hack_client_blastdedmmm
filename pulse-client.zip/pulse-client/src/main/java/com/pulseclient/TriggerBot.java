package com.pulseclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/**
 * Attacks whatever is directly under your crosshair the instant your attack cooldown is full
 * and the target is valid, instead of waiting for a click. On/off state is runtime-only
 * (starts off). Unlike Kill Aura it never changes where you're looking - it only fires when
 * you're already aiming at something.
 */
public final class TriggerBot {
	public static boolean enabled = false;

	public static void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (!enabled || player == null || mc.gameMode == null || mc.screen != null || !player.isAlive()) {
			return;
		}
		if (player.getAttackStrengthScale(0.5f) < 1.0f) {
			return;
		}

		Entity target = mc.crosshairPickEntity;
		if (!isValidTarget(target)) {
			return;
		}

		mc.gameMode.attack(player, target);
		player.swing(InteractionHand.MAIN_HAND);
	}

	private static boolean isValidTarget(Entity e) {
		if (!(e instanceof LivingEntity living) || !living.isAlive() || e instanceof ArmorStand || e.isSpectator()) {
			return false;
		}
		if (e instanceof Player) {
			return PulseConfig.triggerbotPlayers;
		}
		if (e instanceof Enemy) {
			return PulseConfig.triggerbotHostile;
		}
		if (e instanceof Mob) {
			return PulseConfig.triggerbotPassive;
		}
		return false;
	}

	private TriggerBot() {
	}
}
