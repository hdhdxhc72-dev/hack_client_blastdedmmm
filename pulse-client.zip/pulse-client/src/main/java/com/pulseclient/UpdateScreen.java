package com.pulseclient;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Lets you point Pulse at a GitHub repo's Releases and check/download updates from it.
 * See {@link Updater} for exactly what this does and doesn't do automatically.
 */
public class UpdateScreen extends Screen {
	private final Screen parent;
	private EditBox repoBox;
	private int baseY;

	public UpdateScreen(Screen parent) {
		super(Component.literal("Pulse Client - Updates"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 260;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		baseY = Math.max(42, this.height / 2 - 75);
		int y = baseY;

		repoBox = new EditBox(this.font, x, y, w, h, Component.literal("GitHub repo (owner/repo)"));
		repoBox.setMaxLength(100);
		repoBox.setValue(PulseConfig.updateRepo == null ? "" : PulseConfig.updateRepo);
		this.addRenderableWidget(repoBox);
		this.setInitialFocus(repoBox);

		this.addRenderableWidget(Button.builder(Component.literal("Save repo"), (btn) -> {
			PulseConfig.updateRepo = repoBox.getValue().trim();
			PulseConfig.save();
		}).bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(autoCheckLabel(), (btn) -> {
			PulseConfig.autoCheckUpdates = !PulseConfig.autoCheckUpdates;
			btn.setMessage(autoCheckLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Check for updates"), (btn) -> {
			PulseConfig.updateRepo = repoBox.getValue().trim();
			PulseConfig.save();
			Updater.checkNow();
		}).bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Download update"), (btn) -> Updater.downloadUpdate())
				.bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 5 + 16, 150, h)
				.build());
	}

	private static Component autoCheckLabel() {
		return Component.literal("Check on startup: " + (PulseConfig.autoCheckUpdates ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);

		String label = "GitHub repo (owner/repo):";
		graphics.text(this.font, label, this.width / 2 - this.font.width(label) / 2, baseY - 12, 0xFFAAAAAA, true);

		String current = "Installed version: v" + Updater.currentVersion();
		int statusY = baseY + 24 * 5 + 2;
		graphics.text(this.font, current, this.width / 2 - this.font.width(current) / 2, statusY, 0xFFAAAAAA, true);

		String status = Updater.message;
		int color = switch (Updater.state) {
			case ERROR -> 0xFFFF5555;
			case UPDATE_AVAILABLE, DOWNLOADED -> 0xFF55FF55;
			default -> 0xFFFFFFFF;
		};
		graphics.text(this.font, status, this.width / 2 - this.font.width(status) / 2, statusY + 12, color, true);
	}

	@Override
	public void onClose() {
		PulseConfig.updateRepo = repoBox.getValue().trim();
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
