package com.pulseclient;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Checks a GitHub repo's Releases for a newer Pulse Client build and, only when you click
 * "Download update", fetches the new jar into your mods folder next to the current one.
 *
 * This never runs or replaces anything by itself: nothing is contacted until a repo is set
 * (Insert > Updates) and you either click "Check for updates" or leave "check on startup" on,
 * and downloading a new jar doesn't delete the old one or relaunch the game - Minecraft always
 * needs a manual restart to actually load it, same as installing any other mod update.
 */
public final class Updater {
	public enum State {
		IDLE, CHECKING, UP_TO_DATE, UPDATE_AVAILABLE, DOWNLOADING, DOWNLOADED, ERROR
	}

	public static volatile State state = State.IDLE;
	public static volatile String message = "Not checked yet";
	public static volatile String latestVersion = null;
	private static volatile String downloadUrl = null;

	private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "pulseclient-updater");
		t.setDaemon(true);
		return t;
	});

	private static final HttpClient HTTP = HttpClient.newBuilder()
			.connectTimeout(Duration.ofSeconds(10))
			.followRedirects(HttpClient.Redirect.NORMAL)
			.build();

	public static void checkNow() {
		String repo = PulseConfig.updateRepo == null ? "" : PulseConfig.updateRepo.trim();
		if (repo.isEmpty() || !repo.contains("/")) {
			state = State.ERROR;
			message = "Set a repo first (owner/repo)";
			return;
		}
		state = State.CHECKING;
		message = "Checking " + repo + "...";
		EXECUTOR.submit(() -> doCheck(repo));
	}

	private static void doCheck(String repo) {
		try {
			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create("https://api.github.com/repos/" + repo + "/releases/latest"))
					.header("Accept", "application/vnd.github+json")
					.timeout(Duration.ofSeconds(15))
					.GET()
					.build();
			HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());

			if (response.statusCode() == 404) {
				state = State.ERROR;
				message = "No releases found for " + repo;
				return;
			}
			if (response.statusCode() != 200) {
				state = State.ERROR;
				message = "GitHub returned HTTP " + response.statusCode();
				return;
			}

			JsonObject release = JsonParser.parseString(response.body()).getAsJsonObject();
			if (!release.has("tag_name")) {
				state = State.ERROR;
				message = "Release has no tag name";
				return;
			}
			String tag = release.get("tag_name").getAsString();
			String version = (tag.startsWith("v") || tag.startsWith("V")) ? tag.substring(1) : tag;

			String jarUrl = null;
			if (release.has("assets") && release.get("assets").isJsonArray()) {
				JsonArray assets = release.getAsJsonArray("assets");
				for (JsonElement el : assets) {
					JsonObject asset = el.getAsJsonObject();
					String name = asset.has("name") ? asset.get("name").getAsString() : "";
					if (name.endsWith(".jar") && !name.contains("sources")) {
						jarUrl = asset.get("browser_download_url").getAsString();
						break;
					}
				}
			}

			latestVersion = version;
			if (jarUrl == null) {
				state = State.ERROR;
				message = "Found release v" + version + " but it has no .jar file attached";
				return;
			}
			downloadUrl = jarUrl;

			if (version.equals(currentVersion())) {
				state = State.UP_TO_DATE;
				message = "Up to date (v" + currentVersion() + ")";
			} else {
				state = State.UPDATE_AVAILABLE;
				message = "Update available: v" + version + " (you have v" + currentVersion() + ")";
			}
		} catch (IOException | InterruptedException e) {
			if (e instanceof InterruptedException) {
				Thread.currentThread().interrupt();
			}
			state = State.ERROR;
			message = "Check failed: " + e.getMessage();
		} catch (RuntimeException e) {
			state = State.ERROR;
			message = "Check failed: unexpected response from GitHub";
		}
	}

	public static void downloadUpdate() {
		if (state != State.UPDATE_AVAILABLE || downloadUrl == null) {
			return;
		}
		String url = downloadUrl;
		String version = latestVersion;
		state = State.DOWNLOADING;
		message = "Downloading v" + version + "...";
		EXECUTOR.submit(() -> doDownload(url, version));
	}

	private static void doDownload(String url, String version) {
		Path tmp = null;
		try {
			Path modsDir = FabricLoader.getInstance().getGameDir().resolve("mods");
			Path target = modsDir.resolve("pulseclient-" + version + ".jar");
			tmp = modsDir.resolve("pulseclient-" + version + ".jar.download");

			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(url))
					.timeout(Duration.ofMinutes(2))
					.GET()
					.build();
			HttpResponse<Path> response = HTTP.send(request, HttpResponse.BodyHandlers.ofFile(tmp));

			if (response.statusCode() != 200) {
				Files.deleteIfExists(tmp);
				state = State.ERROR;
				message = "Download failed: HTTP " + response.statusCode();
				return;
			}
			if (Files.size(tmp) < 1024) { // a real mod jar is never this small; catches error pages
				Files.deleteIfExists(tmp);
				state = State.ERROR;
				message = "Download failed: response was too small to be a real jar";
				return;
			}

			Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
			state = State.DOWNLOADED;
			message = "Saved mods/" + target.getFileName() + " - remove the old pulseclient jar "
					+ "and restart Minecraft to use it";
		} catch (IOException | InterruptedException e) {
			if (tmp != null) {
				try {
					Files.deleteIfExists(tmp);
				} catch (IOException ignored) {
					// best effort cleanup
				}
			}
			if (e instanceof InterruptedException) {
				Thread.currentThread().interrupt();
			}
			state = State.ERROR;
			message = "Download failed: " + e.getMessage();
		}
	}

	public static String currentVersion() {
		return FabricLoader.getInstance().getModContainer(PulseClient.MOD_ID)
				.map(c -> c.getMetadata().getVersion().getFriendlyString())
				.orElse("?");
	}

	private Updater() {
	}
}
