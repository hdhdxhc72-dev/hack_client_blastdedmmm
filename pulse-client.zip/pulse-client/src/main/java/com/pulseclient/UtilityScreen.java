package com.pulseclient;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Auto Respawn, Anti-AFK, Fullbright and Auto Eat settings. */
public class UtilityScreen extends Screen {
	private final Screen parent;

	public UtilityScreen(Screen parent) {
		super(Component.literal("Pulse Client - Utility"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		final int w = 220;
		final int h = 20;
		final int step = 24;
		int x = this.width / 2 - w / 2;
		int y = Math.max(30, this.height / 2 - 75);

		this.addRenderableWidget(Button.builder(respawnLabel(), (btn) -> {
			AutoRespawn.enabled = !AutoRespawn.enabled;
			btn.setMessage(respawnLabel());
		}).bounds(x, y, w, h).build());

		this.addRenderableWidget(Button.builder(afkLabel(), (btn) -> {
			AntiAFK.enabled = !AntiAFK.enabled;
			btn.setMessage(afkLabel());
		}).bounds(x, y + step, w, h).build());

		this.addRenderableWidget(Button.builder(fullbrightLabel(), (btn) -> {
			Fullbright.enabled = !Fullbright.enabled;
			btn.setMessage(fullbrightLabel());
		}).bounds(x, y + step * 2, w, h).build());

		this.addRenderableWidget(Button.builder(autoEatLabel(), (btn) -> {
			AutoEat.enabled = !AutoEat.enabled;
			btn.setMessage(autoEatLabel());
		}).bounds(x, y + step * 3, w, h).build());

		this.addRenderableWidget(Button.builder(autoEatHungerLabel(), (btn) -> {
			// Cycle 6 -> 10 -> 14 -> 16 -> 18 -> 6
			int[] presets = {6, 10, 14, 16, 18};
			int next = presets[0];
			for (int i = 0; i < presets.length; i++) {
				if (presets[i] == PulseConfig.autoEatHunger) {
					next = presets[(i + 1) % presets.length];
					break;
				}
			}
			PulseConfig.autoEatHunger = next;
			btn.setMessage(autoEatHungerLabel());
			PulseConfig.save();
		}).bounds(x, y + step * 4, w, h).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), (btn) -> this.onClose())
				.bounds(this.width / 2 - 75, y + step * 5 + 6, 150, h)
				.build());
	}

	private static Component respawnLabel() {
		return Component.literal("Auto Respawn: " + (AutoRespawn.enabled ? "ON" : "OFF"));
	}

	private static Component afkLabel() {
		return Component.literal("Anti-AFK: " + (AntiAFK.enabled ? "ON" : "OFF"));
	}

	private static Component fullbrightLabel() {
		return Component.literal("Fullbright (night vision): " + (Fullbright.enabled ? "ON" : "OFF"));
	}

	private static Component autoEatLabel() {
		return Component.literal("Auto Eat: " + (AutoEat.enabled ? "ON" : "OFF"));
	}

	private static Component autoEatHungerLabel() {
		return Component.literal("Eat at hunger: " + PulseConfig.autoEatHunger + " (click to change)");
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		String title = this.title.getString();
		graphics.text(this.font, title, this.width / 2 - this.font.width(title) / 2, 12, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		PulseConfig.save();
		this.minecraft.gui.setScreen(parent);
	}
}
